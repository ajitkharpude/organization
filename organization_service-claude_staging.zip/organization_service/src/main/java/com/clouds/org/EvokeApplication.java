package com.clouds.org;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvokeApplication {

    private static final Logger LOG = LogManager.getLogger(EvokeApplication.class);

    public static void main(String[] args) {
        // ── Graylog system properties ────────────────────────────────────────
        // Must be set BEFORE Spring (and Log4j2 appenders) initialise.
        //
        // K8s YAML injects:
        //   GRAYLOG_IP       → Graylog host IP  (e.g. 10.13.10.12)
        //   GRAYLOG_PORT     → GELF UDP port     (e.g. 12812)
        //   GRAYLOG_ENABLED  → "true" / "false"
        //   GRAYLOG_PROTOCOL → historically set to "true" in some manifests;
        //                       treated as a boolean flag, NOT a protocol string.
        //                       We always use UDP for GELF.
        //
        // log4j2.xml reads:  ${sys:graylog.host},  ${sys:graylog.port},
        //                    ${sys:graylog.protocol}  (expected: "udp" or "tcp")

        // Host: prefer GRAYLOG_IP (set in K8s manifest), fall back to GRAYLOG_HOST
        String graylogHost = envFirst("GRAYLOG_IP", "GRAYLOG_HOST", "10.13.10.12");
        setIfAbsent("graylog.host", graylogHost);

        // Port: K8s injects GRAYLOG_PORT=12812
        setIfAbsent("graylog.port", env("GRAYLOG_PORT", "12812"));

        // Protocol: K8s manifest sets GRAYLOG_PROTOCOL=true (boolean flag, not a string).
        // Normalise: anything other than "tcp" → "udp".
        String rawProtocol = env("GRAYLOG_PROTOCOL", "udp");
        String protocol = "tcp".equalsIgnoreCase(rawProtocol) ? "tcp" : "udp";
        setIfAbsent("graylog.protocol", protocol);

        // Enable flag
        setIfAbsent("graylog.enabled", env("GRAYLOG_ENABLED", "true"));

        try {
            SpringApplication.run(EvokeApplication.class, args);
            LOG.info("organization-service started — graylog={}:{} protocol={}",
                    graylogHost,
                    System.getProperty("graylog.port"),
                    System.getProperty("graylog.protocol"));
        } catch (Exception e) {
            LOG.fatal("organization-service failed to start: {}", e.getMessage(), e);
            throw e;
        }
    }

    /** Sets a system property only if it has not already been provided via -D flag. */
    private static void setIfAbsent(String key, String value) {
        if (System.getProperty(key) == null) {
            System.setProperty(key, value);
        }
    }

    /** Returns the value of the first non-blank env var found, or defaultValue. */
    private static String envFirst(String primary, String secondary, String defaultValue) {
        String v = System.getenv(primary);
        if (v != null && !v.isBlank()) return v;
        v = System.getenv(secondary);
        if (v != null && !v.isBlank()) return v;
        return defaultValue;
    }

    private static String env(String name, String defaultValue) {
        String v = System.getenv(name);
        return (v != null && !v.isBlank()) ? v : defaultValue;
    }
}
