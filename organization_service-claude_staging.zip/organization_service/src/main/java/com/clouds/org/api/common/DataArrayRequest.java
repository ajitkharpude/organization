package com.clouds.org.api.common;

import jakarta.validation.Valid;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Generic inbound envelope. Every endpoint receives its payload wrapped here;
 * only the first element of {@link #dataArray} is processed.
 *
 * @param <T> the concrete request DTO type
 */
@Getter
@Setter
@NoArgsConstructor
public class DataArrayRequest<T> {

    private List<@Valid T> dataArray;

    private String requestId;
}
