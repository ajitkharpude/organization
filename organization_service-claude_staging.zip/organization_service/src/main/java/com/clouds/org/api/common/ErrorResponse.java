package com.clouds.org.api.common;

import lombok.Getter;

import java.time.OffsetDateTime;

/**
 * Standard error envelope. Never carries stack traces or internal detail.
 */
@Getter
public class ErrorResponse {

    private final boolean success = false;
    private final String timestamp;
    private final int status;
    private final String error;
    private final String message;
    private final String path;

    public ErrorResponse(OffsetDateTime timestamp, int status, String error, String message, String path) {
        this.timestamp = timestamp.toString();
        this.status = status;
        this.error = error;
        this.message = message;
        this.path = path;
    }
}
