package com.clouds.org.api.mapper;

import com.clouds.org.api.request.DepartmentRequestDTO;
import com.clouds.org.api.response.DepartmentResponseDTO;
import com.clouds.org.infrastructure.persistence.entity.DepartmentEntity;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface DepartmentMapper {

    DepartmentResponseDTO toResponse(DepartmentEntity entity);

    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "orgProjectId", ignore = true)
    @Mapping(target = "refId", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    DepartmentEntity toEntity(DepartmentRequestDTO dto);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "orgProjectId", ignore = true)
    @Mapping(target = "refId", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    void updateEntity(DepartmentRequestDTO dto, @MappingTarget DepartmentEntity entity);
}
