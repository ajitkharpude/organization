package com.clouds.org.api.mapper;

import com.clouds.org.api.request.DeptUserMappingRequestDTO;
import com.clouds.org.api.response.DeptUserMappingResponseDTO;
import com.clouds.org.infrastructure.persistence.entity.DeptUserMappingEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface DeptUserMappingMapper {

    DeptUserMappingResponseDTO toResponse(DeptUserMappingEntity entity);

    /**
     * Maps the create payload onto a fresh mapping entity. Identity, org/dept
     * wiring, status, and audit fields are assigned in the service layer.
     */
    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "orgProjectId", ignore = true)
    @Mapping(target = "isActive", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    DeptUserMappingEntity toEntity(DeptUserMappingRequestDTO dto);
}
