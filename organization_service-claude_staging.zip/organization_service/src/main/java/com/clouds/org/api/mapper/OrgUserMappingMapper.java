package com.clouds.org.api.mapper;

import com.clouds.org.api.response.OrgUserMappingResponseDTO;
import com.clouds.org.infrastructure.persistence.entity.OrgUserMappingEntity;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrgUserMappingMapper {

    OrgUserMappingResponseDTO toResponse(OrgUserMappingEntity entity);
}
