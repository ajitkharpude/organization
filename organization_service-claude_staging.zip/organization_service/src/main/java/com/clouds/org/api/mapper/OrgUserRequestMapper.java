package com.clouds.org.api.mapper;

import com.clouds.org.api.request.OrgUserRequestDTO;
import com.clouds.org.api.response.OrgUserRequestResponseDTO;
import com.clouds.org.infrastructure.persistence.entity.OrgUserRequestEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrgUserRequestMapper {

    OrgUserRequestResponseDTO toResponse(OrgUserRequestEntity entity);

    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    @Mapping(target = "requestStatus", ignore = true)
    @Mapping(target = "orgProjectId", ignore = true)
    OrgUserRequestEntity toEntity(OrgUserRequestDTO dto);
}
