package com.clouds.org.api.mapper;

import com.clouds.org.api.request.OrgRequestDTO;
import com.clouds.org.api.response.OrgResponseDTO;
import com.clouds.org.infrastructure.persistence.entity.OrganizationEntity;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrganizationMapper {

    OrgResponseDTO toResponse(OrganizationEntity entity);

    /**
     * Maps the create payload onto a fresh org entity. Identity, parent/project
     * wiring, ref, status, and audit fields are assigned in the service layer.
     */
    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "parentOrgId", ignore = true)
    @Mapping(target = "orgProjectId", ignore = true)
    @Mapping(target = "refId", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    OrganizationEntity toEntity(OrgRequestDTO dto);

    /**
     * Applies non-null fields from the update payload onto an existing entity.
     * Identity, parent/project wiring, and ref are never touched.
     */
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "parentOrgId", ignore = true)
    @Mapping(target = "orgProjectId", ignore = true)
    @Mapping(target = "refId", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    void updateEntity(OrgRequestDTO dto, @MappingTarget OrganizationEntity entity);
}
