package com.clouds.org.api.mapper;

import com.clouds.org.api.request.RegisterRequestDTO;
import com.clouds.org.api.request.UserUpdateRequestDTO;
import com.clouds.org.api.response.UserResponseDTO;
import com.clouds.org.infrastructure.persistence.entity.UserEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface UserMapper {

    UserResponseDTO toResponse(UserEntity entity);

    /**
     * Maps the registration payload onto a fresh user entity. Identity, status,
     * ref/role wiring, and audit fields are assigned in the service layer.
     */
    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "refId", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    @Mapping(target = "isActive", ignore = true)
    @Mapping(target = "isSuperAdmin", ignore = true)
    @Mapping(target = "primaryRoleId", ignore = true)
    UserEntity toEntity(RegisterRequestDTO dto);

    /**
     * Merges only non-null fields from the update DTO onto the existing entity.
     * Identity, status, and audit fields are never overwritten here.
     */
    @Mapping(target = "keyVal", ignore = true)
    @Mapping(target = "refId", ignore = true)
    @Mapping(target = "activeStatus", ignore = true)
    @Mapping(target = "isActive", ignore = true)
    @Mapping(target = "isSuperAdmin", ignore = true)
    @Mapping(target = "primaryRoleId", ignore = true)
    @Mapping(target = "orgProjectId", ignore = true)
    @Mapping(target = "officialEmail", ignore = true)
    @Mapping(target = "personalEmail", ignore = true)
    void updateEntity(UserUpdateRequestDTO dto, @MappingTarget UserEntity entity);
}
