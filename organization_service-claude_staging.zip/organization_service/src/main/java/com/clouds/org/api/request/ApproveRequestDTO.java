package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApproveRequestDTO {

    @JsonProperty("primary_role_id")
    private String primaryRoleId;

    @JsonProperty("actioned_by")
    private String actionedBy;
}
