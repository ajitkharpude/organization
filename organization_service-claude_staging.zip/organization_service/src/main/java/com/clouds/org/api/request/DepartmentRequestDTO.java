package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class DepartmentRequestDTO {

    @NotBlank(message = "title is required")
    @JsonProperty("title")
    private String title;

    @JsonProperty("description")
    private String description;

    @JsonProperty("org_web_site")
    private String orgWebSite;

    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("parent_task_id")
    private String parentTaskId;

    /** 1 marks this department as the org default; 0 otherwise. */
    @JsonProperty("default_obj")
    private Integer defaultObj;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country")
    private String country;

    @JsonProperty("country_code")
    private String countryCode;

    @JsonProperty("continent")
    private String continent;

    @JsonProperty("location")
    private String location;

    @JsonProperty("latitude")
    private BigDecimal latitude;

    @JsonProperty("longitude")
    private BigDecimal longitude;

    @JsonProperty("zipcode")
    private String zipcode;

    @JsonProperty("timezone")
    private String timezone;

    @JsonProperty("project_id")
    private String projectId;

    @JsonProperty("listing_id")
    private String listingId;
}
