package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeptUserMappingRequestDTO {

    @NotBlank(message = "dept_project_id is required")
    @JsonProperty("dept_project_id")
    private String deptProjectId;

    @NotBlank(message = "official_email is required")
    @Email(message = "official_email must be a valid email")
    @JsonProperty("official_email")
    private String officialEmail;

    @JsonProperty("role_type")
    private Integer roleType;
}
