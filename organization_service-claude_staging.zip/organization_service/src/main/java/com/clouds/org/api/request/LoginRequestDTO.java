package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequestDTO {

    @JsonProperty("org_project_id")
    private String orgProjectId;

    @NotBlank(message = "password is required")
    @JsonProperty("password")
    private String password;

    @JsonProperty("userDeviceId")
    private String userDeviceId;

    @JsonProperty("requestId")
    private String requestId;

    @JsonProperty("userId")
    private String userId;

    @NotBlank(message = "official_email is required")
    @Email(message = "official_email must be a valid email")
    @JsonProperty("official_email")
    private String officialEmail;
}
