package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class OrgRequestDTO {

    @NotBlank(message = "title is required")
    @JsonProperty("title")
    private String title;

    @JsonProperty("description")
    private String description;

    @JsonProperty("org_category")
    private String orgCategory;

    @JsonProperty("org_web_site")
    private String orgWebSite;

    @JsonProperty("template_id")
    private String templateId;

    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country")
    private String country;

    @JsonProperty("country_code")
    private String countryCode;

    @JsonProperty("continent")
    private String continent;

    @JsonProperty("location")
    private String location;

    @JsonProperty("latitude")
    private BigDecimal latitude;

    @JsonProperty("longitude")
    private BigDecimal longitude;

    @JsonProperty("zipcode")
    private String zipcode;

    @JsonProperty("timezone")
    private String timezone;

    @JsonProperty("project_id")
    private String projectId;

    @JsonProperty("listing_id")
    private String listingId;

    @JsonProperty("show_compare_graph")
    private Integer showCompareGraph;

    @JsonProperty("property_sync_to_clouzer")
    private Boolean propertySyncToClouzer;
}
