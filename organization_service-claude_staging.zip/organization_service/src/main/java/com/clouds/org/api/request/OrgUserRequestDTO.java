package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrgUserRequestDTO {

    @NotBlank(message = "official_email is required")
    @Email(message = "official_email must be a valid email")
    @JsonProperty("official_email")
    private String officialEmail;

    @Email(message = "personal_email must be a valid email")
    @JsonProperty("personal_email")
    private String personalEmail;

    @JsonProperty("org_web_site")
    private String orgWebSite;
}
