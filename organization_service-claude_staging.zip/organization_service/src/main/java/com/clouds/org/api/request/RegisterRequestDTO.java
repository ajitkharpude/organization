package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class RegisterRequestDTO {

    @NotBlank(message = "first_name is required")
    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("middle_name")
    private String middleName;

    @NotBlank(message = "last_name is required")
    @JsonProperty("last_name")
    private String lastName;

    @NotBlank(message = "org_project_id is required")
    @JsonProperty("org_project_id")
    private String orgProjectId;

    @JsonProperty("verificationCode")
    private String verificationCode;

    @NotBlank(message = "personal_email is required")
    @Email(message = "personal_email must be a valid email")
    @JsonProperty("personal_email")
    private String personalEmail;

    @NotBlank(message = "password is required")
    @JsonProperty("password")
    private String password;

    @NotBlank(message = "official_email is required")
    @Email(message = "official_email must be a valid email")
    @JsonProperty("official_email")
    private String officialEmail;

    @JsonProperty("contact_number")
    private String contactNumber;

    @JsonProperty("domain")
    private String domain;

    @JsonProperty("dial_code")
    private String dialCode;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country")
    private String country;

    @JsonProperty("country_code")
    private String countryCode;

    @JsonProperty("continent")
    private String continent;

    @JsonProperty("location")
    private String location;

    @JsonProperty("latitude")
    private BigDecimal latitude;

    @JsonProperty("longitude")
    private BigDecimal longitude;

    @JsonProperty("zipcode")
    private String zipcode;

    @JsonProperty("timezone")
    private String timezone;
}
