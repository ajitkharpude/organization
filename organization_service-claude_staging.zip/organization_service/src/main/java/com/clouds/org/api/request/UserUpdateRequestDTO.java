package com.clouds.org.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Editable profile fields for an existing user. Identity ({@code key_val}),
 * emails, and org/dept wiring are never updated through this DTO.
 */
@Getter
@Setter
public class UserUpdateRequestDTO {

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("middle_name")
    private String middleName;

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("contact_number")
    private String contactNumber;

    @JsonProperty("dial_code")
    private String dialCode;

    @JsonProperty("user_image")
    private String userImage;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country")
    private String country;

    @JsonProperty("country_code")
    private String countryCode;

    @JsonProperty("continent")
    private String continent;

    @JsonProperty("location")
    private String location;

    @JsonProperty("latitude")
    private BigDecimal latitude;

    @JsonProperty("longitude")
    private BigDecimal longitude;

    @JsonProperty("zipcode")
    private String zipcode;

    @JsonProperty("timezone")
    private String timezone;
}
