package com.clouds.org.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class DepartmentResponseDTO {

    @JsonProperty("key_val")
    private String keyVal;

    @JsonProperty("active_status")
    private Integer activeStatus;

    @JsonProperty("title")
    private String title;

    @JsonProperty("description")
    private String description;

    @JsonProperty("org_web_site")
    private String orgWebSite;

    @JsonProperty("ref_id")
    private String refId;

    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("parent_task_id")
    private String parentTaskId;

    @JsonProperty("default_obj")
    private Integer defaultObj;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country")
    private String country;

    @JsonProperty("country_code")
    private String countryCode;

    @JsonProperty("continent")
    private String continent;

    @JsonProperty("location")
    private String location;

    @JsonProperty("latitude")
    private BigDecimal latitude;

    @JsonProperty("longitude")
    private BigDecimal longitude;

    @JsonProperty("zipcode")
    private String zipcode;

    @JsonProperty("timezone")
    private String timezone;

    @JsonProperty("org_project_id")
    private String orgProjectId;

    @JsonProperty("project_id")
    private String projectId;

    @JsonProperty("dept_project_id")
    private String deptProjectId;

    @JsonProperty("listing_id")
    private String listingId;

    @JsonProperty("created_by")
    private String createdBy;

    @JsonProperty("created_on")
    private LocalDateTime createdOn;

    @JsonProperty("last_modified_by")
    private String lastModifiedBy;

    @JsonProperty("last_modified_on")
    private LocalDateTime lastModifiedOn;
}
