package com.clouds.org.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Getter
@Setter
public class DeptUserMappingResponseDTO {

    @JsonProperty("key_val")
    private String keyVal;

    @JsonProperty("org_project_id")
    private String orgProjectId;

    @JsonProperty("dept_project_id")
    private String deptProjectId;

    @JsonProperty("official_email")
    private String officialEmail;

    @JsonProperty("role_type")
    private Integer roleType;

    @JsonProperty("is_active")
    private Integer isActive;

    @JsonProperty("active_status")
    private Integer activeStatus;

    @JsonProperty("created_by")
    private String createdBy;

    @JsonProperty("created_on")
    private LocalDateTime createdOn;

    @JsonProperty("last_modified_by")
    private String lastModifiedBy;

    @JsonProperty("last_modified_on")
    private LocalDateTime lastModifiedOn;

    /** Who removed this user from the department (null if still active). */
    @JsonProperty("removed_by")
    private String removedBy;

    /** When this user was removed from the department (null if still active). */
    @JsonProperty("removed_on")
    private OffsetDateTime removedOn;
}
