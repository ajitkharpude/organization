package com.clouds.org.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class OrgResponseDTO {

    @JsonProperty("key_val")
    private String keyVal;

    @JsonProperty("parent_org_id")
    private String parentOrgId;

    @JsonProperty("org_project_id")
    private String orgProjectId;

    @JsonProperty("ref_id")
    private String refId;

    @JsonProperty("title")
    private String title;

    @JsonProperty("active_status")
    private Integer activeStatus;

    @JsonProperty("org_web_site")
    private String orgWebSite;

    @JsonProperty("org_category")
    private String orgCategory;

    @JsonProperty("description")
    private String description;

    @JsonProperty("template_id")
    private String templateId;

    @JsonProperty("image_path")
    private String imagePath;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country")
    private String country;

    @JsonProperty("country_code")
    private String countryCode;

    @JsonProperty("continent")
    private String continent;

    @JsonProperty("location")
    private String location;

    @JsonProperty("latitude")
    private BigDecimal latitude;

    @JsonProperty("longitude")
    private BigDecimal longitude;

    @JsonProperty("zipcode")
    private String zipcode;

    @JsonProperty("timezone")
    private String timezone;

    @JsonProperty("project_id")
    private String projectId;

    @JsonProperty("listing_id")
    private String listingId;

    @JsonProperty("show_compare_graph")
    private Integer showCompareGraph;

    @JsonProperty("property_sync_to_clouzer")
    private Boolean propertySyncToClouzer;

    @JsonProperty("created_by")
    private String createdBy;

    @JsonProperty("created_on")
    private LocalDateTime createdOn;

    @JsonProperty("last_modified_by")
    private String lastModifiedBy;

    @JsonProperty("last_modified_on")
    private LocalDateTime lastModifiedOn;
}
