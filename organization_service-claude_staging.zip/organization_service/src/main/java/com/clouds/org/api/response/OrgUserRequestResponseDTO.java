package com.clouds.org.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class OrgUserRequestResponseDTO {

    @JsonProperty("key_val")
    private String keyVal;

    @JsonProperty("active_status")
    private Integer activeStatus;

    @JsonProperty("request_status")
    private Integer requestStatus;

    @JsonProperty("official_email")
    private String officialEmail;

    @JsonProperty("personal_email")
    private String personalEmail;

    @JsonProperty("org_web_site")
    private String orgWebSite;

    @JsonProperty("org_project_id")
    private String orgProjectId;

    @JsonProperty("actioned_by")
    private String actionedBy;

    @JsonProperty("actioned_on")
    private LocalDateTime actionedOn;

    @JsonProperty("created_by")
    private String createdBy;

    @JsonProperty("created_on")
    private LocalDateTime createdOn;

    @JsonProperty("last_modified_by")
    private String lastModifiedBy;

    @JsonProperty("last_modified_on")
    private LocalDateTime lastModifiedOn;
}
