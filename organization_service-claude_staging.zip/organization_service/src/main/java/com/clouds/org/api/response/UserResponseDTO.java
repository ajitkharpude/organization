package com.clouds.org.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * User profile projection. Never carries the password or any credential field.
 */
@Getter
@Setter
public class UserResponseDTO {

	@JsonProperty("key_val")
	private String keyVal;

	@JsonProperty("ref_id")
	private String refId;

	@JsonProperty("active_status")
	private Integer activeStatus;

	@JsonProperty("is_active")
	private Integer isActive;

	@JsonProperty("is_super_admin")
	private Integer isSuperAdmin;

	@JsonProperty("first_name")
	private String firstName;

	@JsonProperty("middle_name")
	private String middleName;

	@JsonProperty("last_name")
	private String lastName;

	@JsonProperty("official_email")
	private String officialEmail;

	@JsonProperty("personal_email")
	private String personalEmail;

	@JsonProperty("contact_number")
	private String contactNumber;

	@JsonProperty("employee_id")
	private Long employeeId;

	@JsonProperty("primary_role_id")
	private String primaryRoleId;

	@JsonProperty("dial_code")
	private String dialCode;

	@JsonProperty("domain")
	private String domain;

	@JsonProperty("org_project_id")
	private String orgProjectId;

	@JsonProperty("city")
	private String city;

	@JsonProperty("state")
	private String state;

	@JsonProperty("country")
	private String country;

	@JsonProperty("country_code")
	private String countryCode;

	@JsonProperty("continent")
	private String continent;

	@JsonProperty("location")
	private String location;

	@JsonProperty("latitude")
	private BigDecimal latitude;

	@JsonProperty("longitude")
	private BigDecimal longitude;

	@JsonProperty("zipcode")
	private String zipcode;

	@JsonProperty("timezone")
	private String timezone;

	@JsonProperty("created_on")
	private LocalDateTime createdOn;

	@JsonProperty("last_modified_on")
	private LocalDateTime lastModifiedOn;
}
