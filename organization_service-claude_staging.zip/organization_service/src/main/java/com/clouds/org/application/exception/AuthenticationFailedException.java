package com.clouds.org.application.exception;

/**
 * Thrown when a login attempt fails because the supplied credentials are
 * wrong (password does not match). Distinct from {@link ResourceNotFoundException}
 * (no such account) and from the inactive-account case handled by
 * {@link InvalidRequestException}. Maps to HTTP 401.
 */
public class AuthenticationFailedException extends RuntimeException {

    public AuthenticationFailedException(String message) {
        super(message);
    }
}
