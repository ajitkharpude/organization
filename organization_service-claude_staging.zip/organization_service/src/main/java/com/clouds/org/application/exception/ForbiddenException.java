package com.clouds.org.application.exception;

/** Thrown when an operation is not permitted (e.g. mutating the super org). Maps to HTTP 403. */
public class ForbiddenException extends RuntimeException {

    public ForbiddenException(String message) {
        super(message);
    }
}
