package com.clouds.org.application.exception;

/** Thrown for malformed or business-invalid requests. Maps to HTTP 400. */
public class InvalidRequestException extends RuntimeException {

    public InvalidRequestException(String message) {
        super(message);
    }
}
