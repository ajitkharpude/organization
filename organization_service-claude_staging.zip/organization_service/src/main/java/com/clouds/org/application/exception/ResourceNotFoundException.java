package com.clouds.org.application.exception;

/** Thrown when a requested aggregate does not exist (or is soft-deleted). Maps to HTTP 404. */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
