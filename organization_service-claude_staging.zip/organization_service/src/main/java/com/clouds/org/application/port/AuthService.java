package com.clouds.org.application.port;

import com.clouds.org.api.request.LoginRequestDTO;
import com.clouds.org.api.request.RegisterRequestDTO;
import com.clouds.org.api.response.UserResponseDTO;

public interface AuthService {

    UserResponseDTO register(RegisterRequestDTO request);

    UserResponseDTO login(LoginRequestDTO request);
}
