package com.clouds.org.application.port;

import com.clouds.org.api.request.DepartmentRequestDTO;
import com.clouds.org.api.response.DepartmentResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface DepartmentService {

    DepartmentResponseDTO create(String orgKey, DepartmentRequestDTO request);

    DepartmentResponseDTO update(String orgKey, String deptKey, DepartmentRequestDTO request);

    DepartmentResponseDTO get(String orgKey, String deptKey);

    void softDelete(String orgKey, String deptKey);

    Page<DepartmentResponseDTO> search(String orgKey, String title, Pageable pageable);
}
