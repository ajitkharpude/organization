package com.clouds.org.application.port;

import com.clouds.org.api.request.DeptUserMappingRequestDTO;
import com.clouds.org.api.response.DeptUserMappingResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface DeptUserMappingService {

    DeptUserMappingResponseDTO create(String orgKey, DeptUserMappingRequestDTO request);

    DeptUserMappingResponseDTO get(String orgKey, String mappingKey);

    Page<DeptUserMappingResponseDTO> search(String orgKey, String deptKey, String email, Pageable pageable);

    /**
     * Removes a user from a department: soft-deletes the mapping row.
     */
    void removeUserFromDept(String orgKey, String mappingKey);
}
