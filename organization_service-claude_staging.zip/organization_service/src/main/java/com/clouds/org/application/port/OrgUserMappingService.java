package com.clouds.org.application.port;

import com.clouds.org.api.response.OrgUserMappingResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface OrgUserMappingService {

    OrgUserMappingResponseDTO get(String orgKey, String mappingKey);

    Page<OrgUserMappingResponseDTO> search(String orgKey, String email, Pageable pageable);

    /**
     * Removes a user from an organization: soft-deletes the org mapping and
     * cascades to soft-delete all of that user's department mappings within
     * the same org.
     */
    void removeUserFromOrg(String orgKey, String mappingKey);
}
