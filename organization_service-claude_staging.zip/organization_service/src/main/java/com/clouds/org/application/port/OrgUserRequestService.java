package com.clouds.org.application.port;

import com.clouds.org.api.request.ApproveRequestDTO;
import com.clouds.org.api.request.OrgUserRequestDTO;
import com.clouds.org.api.response.OrgUserRequestResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface OrgUserRequestService {

    OrgUserRequestResponseDTO createRequest(String orgKey, OrgUserRequestDTO request);

    OrgUserRequestResponseDTO approve(String orgKey, String requestKey, ApproveRequestDTO request);

    OrgUserRequestResponseDTO reject(String orgKey, String requestKey);

    OrgUserRequestResponseDTO cancel(String orgKey, String requestKey);

    Page<OrgUserRequestResponseDTO> search(String orgKey, Integer status, String email, Pageable pageable);
}
