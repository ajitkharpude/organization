package com.clouds.org.application.port;

import com.clouds.org.api.request.OrgRequestDTO;
import com.clouds.org.api.response.OrgResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface OrganizationService {

    OrgResponseDTO create(OrgRequestDTO request);

    OrgResponseDTO update(String keyVal, OrgRequestDTO request);

    OrgResponseDTO getByKeyVal(String keyVal);

    void softDelete(String keyVal);

    Page<OrgResponseDTO> search(String title, Pageable pageable);
}
