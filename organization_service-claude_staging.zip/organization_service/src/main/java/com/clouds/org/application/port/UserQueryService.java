package com.clouds.org.application.port;

import com.clouds.org.api.response.UserResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserQueryService {

    Page<UserResponseDTO> search(String firstName, String lastName, String officialEmail,
                                 String personalEmail, String orgKey, Pageable pageable);
}
