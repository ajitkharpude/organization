package com.clouds.org.application.port;

import com.clouds.org.api.request.UserUpdateRequestDTO;
import com.clouds.org.api.response.UserResponseDTO;

public interface UserService {

    UserResponseDTO update(String keyVal, UserUpdateRequestDTO request);

    /**
     * Soft-deletes a user and cascades the deletion across every dependent
     * record: all org-user mappings, all department-user mappings, any
     * still-pending org-user requests (cancelled), and the login credential.
     */
    void delete(String keyVal);
}
