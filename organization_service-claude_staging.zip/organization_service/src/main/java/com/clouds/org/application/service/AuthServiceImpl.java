package com.clouds.org.application.service;

import com.clouds.org.api.mapper.UserMapper;
import com.clouds.org.api.request.LoginRequestDTO;
import com.clouds.org.api.request.RegisterRequestDTO;
import com.clouds.org.api.response.UserResponseDTO;
import com.clouds.org.application.exception.AuthenticationFailedException;
import com.clouds.org.application.exception.DuplicateResourceException;
import com.clouds.org.application.exception.InvalidRequestException;
import com.clouds.org.application.exception.ResourceNotFoundException;
import com.clouds.org.application.port.AuthService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.domain.WizardType;
import com.clouds.org.infrastructure.config.EvokeProperties;
import com.clouds.org.infrastructure.persistence.entity.UserCredentialEntity;
import com.clouds.org.infrastructure.persistence.entity.UserEntity;
import com.clouds.org.infrastructure.persistence.entity.WizardEntity;
import com.clouds.org.infrastructure.persistence.repository.UserCredentialRepository;
import com.clouds.org.infrastructure.persistence.repository.UserRepository;
import com.clouds.org.infrastructure.persistence.repository.WizardRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private static final int IS_ACTIVE = 1;
    private static final int NOT_SUPER_ADMIN = 0;
    private final UserRepository userRepository;
    private final UserCredentialRepository credentialRepository;
    private final WizardRepository wizardRepository;
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;
    private final EvokeProperties properties;

    @Override
    @Transactional
    public UserResponseDTO register(RegisterRequestDTO request) {
        if (!properties.getSuperOrgId().equals(request.getOrgProjectId())) {
            log.warn("Register rejected: org_project_id {} is not the super org", request.getOrgProjectId());
            throw new InvalidRequestException("Registration must be performed under the parent organization");
        }

        if (userRepository.existsByOfficialEmail(request.getOfficialEmail())) {
            log.warn("Register rejected: official_email already exists: {}", request.getOfficialEmail());
            throw new DuplicateResourceException("An account with this official email already exists");
        }
        if (userRepository.existsByPersonalEmail(request.getPersonalEmail())) {
            log.warn("Register rejected: personal_email already exists: {}", request.getPersonalEmail());
            throw new DuplicateResourceException("An account with this personal email already exists");
        }

        UserEntity user = userMapper.toEntity(request);
        user.setKeyVal(UUID.randomUUID().toString());
        user.setActiveStatus(ActiveStatus.ACTIVE);
        user.setIsActive(IS_ACTIVE);
        user.setIsSuperAdmin(NOT_SUPER_ADMIN);
        user.setRefId(resolveUserWizardRefId(request.getOrgProjectId()));
        user.setPrimaryRoleId("TSK_ROL_LST_0010");
        user.setCreatedBy(request.getOfficialEmail());
        user.setLastModifiedBy(request.getOfficialEmail());

        UserEntity savedUser = userRepository.save(user);
        log.info("===== USER BEFORE SAVE =====");
        log.info("employeeId = {}", user.getEmployeeId());
        log.info("officialEmail = {}", user.getOfficialEmail());
        log.info("orgProjectId = {}", user.getOrgProjectId());
        log.info("user = {}", user);
        UserCredentialEntity credential = new UserCredentialEntity();
        credential.setOfficialEmail(savedUser.getOfficialEmail());
        credential.setPersonalEmail(savedUser.getPersonalEmail());
        credential.setPassword(passwordEncoder.encode(request.getPassword()));
        credential.setContactId(savedUser.getKeyVal());
        credential.setActiveStatus(ActiveStatus.ACTIVE);
        credentialRepository.save(credential);

        return userMapper.toResponse(savedUser);
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponseDTO login(LoginRequestDTO request) {
        UserCredentialEntity credential = credentialRepository.findById(request.getOfficialEmail())
                .orElseThrow(() -> {
                    log.warn("Login failed: no credentials for email: {}", request.getOfficialEmail());
                    return new ResourceNotFoundException("Account not found");
                });

        if (!Integer.valueOf(ActiveStatus.ACTIVE).equals(credential.getActiveStatus())) {
            log.warn("Login failed: inactive credentials for email: {}", request.getOfficialEmail());
            throw new InvalidRequestException("Account is not active");
        }

        UserEntity user = userRepository.findById(credential.getContactId())
                .orElseThrow(() -> {
                    log.warn("Login failed: missing user for credentials: {}", request.getOfficialEmail());
                    return new ResourceNotFoundException("Account not found");
                });

        if (!Integer.valueOf(ActiveStatus.ACTIVE).equals(user.getActiveStatus())
                || !Integer.valueOf(IS_ACTIVE).equals(user.getIsActive())) {
            log.warn("Login failed: inactive user for email: {}", request.getOfficialEmail());
            throw new InvalidRequestException("Account is not active");
        }

        if (!passwordEncoder.matches(request.getPassword(), credential.getPassword())) {
            log.warn("Login failed for email: {}", request.getOfficialEmail());
            throw new AuthenticationFailedException("Invalid credentials");
        }

        return userMapper.toResponse(user);
    }

    /**
     * Resolves the USER-type wizard for the given org. Returns {@code null}
     * (with a warning) when none exists — registration must still proceed.
     */
    private String resolveUserWizardRefId(String orgProjectId) {
        return wizardRepository
                .findFirstByOrgProjectIdAndWizardTypeAndActiveStatus(
                        orgProjectId, WizardType.USER.name(), ActiveStatus.ACTIVE)
                .map(WizardEntity::getKeyVal)
                .orElseGet(() -> {
                    log.warn("No USER wizard found for org {}; proceeding with null ref_id", orgProjectId);
                    return null;
                });
    }
}
