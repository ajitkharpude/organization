package com.clouds.org.application.service;

import com.clouds.org.api.mapper.DepartmentMapper;
import com.clouds.org.api.request.DepartmentRequestDTO;
import com.clouds.org.api.response.DepartmentResponseDTO;
import com.clouds.org.application.exception.ResourceNotFoundException;
import com.clouds.org.application.port.DepartmentService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.domain.WizardType;
import com.clouds.org.infrastructure.persistence.entity.DepartmentEntity;
import com.clouds.org.infrastructure.persistence.entity.WizardEntity;
import com.clouds.org.infrastructure.persistence.repository.DepartmentRepository;
import com.clouds.org.infrastructure.persistence.repository.OrganizationRepository;
import com.clouds.org.infrastructure.persistence.repository.WizardRepository;
import com.clouds.org.infrastructure.persistence.spec.DepartmentSpecifications;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private static final String SYSTEM_ACTOR = "system";
    private static final int DEFAULT_FLAG = 1;

    private final DepartmentRepository departmentRepository;
    private final OrganizationRepository organizationRepository;
    private final WizardRepository wizardRepository;
    private final DepartmentMapper departmentMapper;

    @Override
    @Transactional
    public DepartmentResponseDTO create(String orgKey, DepartmentRequestDTO request) {
        log.info("Creating department in org={} title={}", orgKey, request.getTitle());
        requireActiveOrg(orgKey);

        DepartmentEntity dept = departmentMapper.toEntity(request);
        String keyVal = UUID.randomUUID().toString();
        dept.setKeyVal(keyVal);
        dept.setOrgProjectId(orgKey);
        dept.setRefId(resolveDeptWizardRefId(orgKey));
        dept.setActiveStatus(ActiveStatus.ACTIVE);
        dept.setCreatedBy(SYSTEM_ACTOR);
        dept.setLastModifiedBy(SYSTEM_ACTOR);

        if (isDefault(request.getDefaultObj())) {
            log.debug("Clearing existing default department for org={}", orgKey);
            departmentRepository.clearDefaultForOrg(orgKey, keyVal);
        }

        DepartmentResponseDTO result = departmentMapper.toResponse(departmentRepository.save(dept));
        log.info("Department created: key={} org={}", result.getKeyVal(), orgKey);
        return result;
    }

    @Override
    @Transactional
    public DepartmentResponseDTO update(String orgKey, String deptKey, DepartmentRequestDTO request) {
        log.info("Updating department key={} org={}", deptKey, orgKey);
        requireActiveOrg(orgKey);
        DepartmentEntity dept = loadActiveForOrg(orgKey, deptKey);

        if (isDefault(request.getDefaultObj())) {
            log.debug("Clearing existing default department for org={}", orgKey);
            departmentRepository.clearDefaultForOrg(orgKey, deptKey);
        }

        departmentMapper.updateEntity(request, dept);
        dept.setLastModifiedBy(SYSTEM_ACTOR);

        DepartmentResponseDTO result = departmentMapper.toResponse(departmentRepository.save(dept));
        log.info("Department updated: key={} org={}", deptKey, orgKey);
        return result;
    }

    @Override
    @Transactional(readOnly = true)
    public DepartmentResponseDTO get(String orgKey, String deptKey) {
        log.debug("Fetching department key={} org={}", deptKey, orgKey);
        return departmentMapper.toResponse(loadActiveForOrg(orgKey, deptKey));
    }

    @Override
    @Transactional
    public void softDelete(String orgKey, String deptKey) {
        log.info("Soft-deleting department key={} org={}", deptKey, orgKey);
        DepartmentEntity dept = loadActiveForOrg(orgKey, deptKey);
        dept.setActiveStatus(ActiveStatus.DELETED);
        dept.setLastModifiedBy(SYSTEM_ACTOR);
        departmentRepository.save(dept);
        log.info("Department soft-deleted: key={} org={}", deptKey, orgKey);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<DepartmentResponseDTO> search(String orgKey, String title, Pageable pageable) {
        log.debug("Searching departments org={} title={} page={}", orgKey, title, pageable.getPageNumber());
        Specification<DepartmentEntity> spec = DepartmentSpecifications.activeStatus(ActiveStatus.ACTIVE)
                .and(DepartmentSpecifications.orgProjectId(orgKey))
                .and(DepartmentSpecifications.titleContains(title));
        Page<DepartmentResponseDTO> result = departmentRepository.findAll(spec, pageable).map(departmentMapper::toResponse);
        log.debug("Department search result: org={} total={}", orgKey, result.getTotalElements());
        return result;
    }

    private void requireActiveOrg(String orgKey) {
        organizationRepository.findByKeyValAndActiveStatus(orgKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found: " + orgKey));
    }

    private DepartmentEntity loadActiveForOrg(String orgKey, String deptKey) {
        return departmentRepository
                .findByKeyValAndOrgProjectIdAndActiveStatus(deptKey, orgKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department not found: " + deptKey + " in organization " + orgKey));
    }

    private boolean isDefault(Integer defaultObj) {
        return defaultObj != null && defaultObj == DEFAULT_FLAG;
    }

    private String resolveDeptWizardRefId(String orgProjectId) {
        return wizardRepository
                .findFirstByOrgProjectIdAndWizardTypeAndActiveStatus(
                        orgProjectId, WizardType.DEPT.name(), ActiveStatus.ACTIVE)
                .map(WizardEntity::getKeyVal)
                .orElseGet(() -> {
                    log.warn("No DEPT wizard found for org {}; proceeding with null ref_id", orgProjectId);
                    return null;
                });
    }
}
