package com.clouds.org.application.service;

import com.clouds.org.api.mapper.DeptUserMappingMapper;
import com.clouds.org.api.request.DeptUserMappingRequestDTO;
import com.clouds.org.api.response.DeptUserMappingResponseDTO;
import com.clouds.org.application.exception.DuplicateResourceException;
import com.clouds.org.application.exception.ResourceNotFoundException;
import com.clouds.org.application.port.DeptUserMappingService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.infrastructure.persistence.entity.DeptUserMappingEntity;
import com.clouds.org.infrastructure.persistence.repository.DeptUserMappingRepository;
import com.clouds.org.infrastructure.persistence.repository.DepartmentRepository;
import com.clouds.org.infrastructure.persistence.repository.OrganizationRepository;
import com.clouds.org.infrastructure.persistence.spec.DeptUserMappingSpecifications;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class DeptUserMappingServiceImpl implements DeptUserMappingService {

    private static final String SYSTEM_ACTOR = "system";
    private static final int IS_ACTIVE = 1;
    private static final int DEFAULT_ROLE_TYPE = 2;

    private final DeptUserMappingRepository mappingRepository;
    private final DepartmentRepository departmentRepository;
    private final OrganizationRepository organizationRepository;
    private final DeptUserMappingMapper mappingMapper;

    @Override
    @Transactional
    public DeptUserMappingResponseDTO create(String orgKey, DeptUserMappingRequestDTO request) {
        log.info("Mapping user to department org={} dept={} email={}",
                orgKey, request.getDeptProjectId(), request.getOfficialEmail());
        requireActiveOrg(orgKey);
        requireActiveDept(orgKey, request.getDeptProjectId());

        // Application-layer duplicate guard — enforces one active mapping per email per dept.
        // This mirrors the partial unique index on the production DB (WHERE active_status = 1)
        // and is the authoritative check for H2 (used in tests) which does not support partial indexes.
        if (mappingRepository.existsByDeptProjectIdAndOfficialEmailAndActiveStatus(
                request.getDeptProjectId(), request.getOfficialEmail(), ActiveStatus.ACTIVE)) {
            log.warn("Duplicate department mapping rejected: email={} dept={}",
                    request.getOfficialEmail(), request.getDeptProjectId());
            throw new DuplicateResourceException(
                    "This user is already mapped to this department");
        }

        DeptUserMappingEntity entity = mappingMapper.toEntity(request);
        entity.setKeyVal(UUID.randomUUID().toString());
        entity.setOrgProjectId(orgKey);
        entity.setRoleType(request.getRoleType() != null ? request.getRoleType() : DEFAULT_ROLE_TYPE);
        entity.setIsActive(IS_ACTIVE);
        entity.setActiveStatus(ActiveStatus.ACTIVE);
        entity.setCreatedBy(SYSTEM_ACTOR);
        entity.setLastModifiedBy(SYSTEM_ACTOR);

        try {
            DeptUserMappingEntity saved = mappingRepository.saveAndFlush(entity);
            log.info("Department mapping created: key={} dept={} email={}",
                    saved.getKeyVal(), request.getDeptProjectId(), request.getOfficialEmail());
            return mappingMapper.toResponse(saved);
        } catch (DataIntegrityViolationException ex) {
            log.warn("Duplicate department mapping for {} in dept {}",
                    request.getOfficialEmail(), request.getDeptProjectId());
            throw new DuplicateResourceException(
                    "This user is already mapped to this department");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public DeptUserMappingResponseDTO get(String orgKey, String mappingKey) {
        log.debug("Fetching department mapping key={} org={}", mappingKey, orgKey);
        return mappingMapper.toResponse(loadActiveForOrg(orgKey, mappingKey));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<DeptUserMappingResponseDTO> search(String orgKey, String deptKey, String email, Pageable pageable) {
        log.debug("Searching department mappings org={} dept={} email={} page={}",
                orgKey, deptKey, email, pageable.getPageNumber());
        Specification<DeptUserMappingEntity> spec = DeptUserMappingSpecifications.activeStatus(ActiveStatus.ACTIVE)
                .and(DeptUserMappingSpecifications.orgProjectId(orgKey))
                .and(DeptUserMappingSpecifications.deptProjectId(deptKey))
                .and(DeptUserMappingSpecifications.officialEmailContains(email));
        Page<DeptUserMappingResponseDTO> result =
                mappingRepository.findAll(spec, pageable).map(mappingMapper::toResponse);
        log.debug("Department mapping search result: org={} total={}", orgKey, result.getTotalElements());
        return result;
    }

    @Override
    @Transactional
    public void removeUserFromDept(String orgKey, String mappingKey) {
        log.info("Removing user from department: mappingKey={} org={}", mappingKey, orgKey);
        DeptUserMappingEntity entity = loadActiveForOrg(orgKey, mappingKey);
        entity.setActiveStatus(ActiveStatus.DELETED);
        entity.setIsActive(0);
        entity.setLastModifiedBy(SYSTEM_ACTOR);
        entity.setRemovedBy(SYSTEM_ACTOR);
        entity.setRemovedOn(OffsetDateTime.now());
        mappingRepository.save(entity);
        log.info("User removed from department: mappingKey={} org={}", mappingKey, orgKey);
    }

    private void requireActiveOrg(String orgKey) {
        organizationRepository.findByKeyValAndActiveStatus(orgKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found: " + orgKey));
    }

    private void requireActiveDept(String orgKey, String deptKey) {
        departmentRepository.findByKeyValAndOrgProjectIdAndActiveStatus(deptKey, orgKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department not found: " + deptKey + " in organization " + orgKey));
    }

    private DeptUserMappingEntity loadActiveForOrg(String orgKey, String mappingKey) {
        DeptUserMappingEntity entity = mappingRepository
                .findByKeyValAndActiveStatus(mappingKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("Department mapping not found: " + mappingKey));

        if (!orgKey.equals(entity.getOrgProjectId())) {
            log.warn("Department mapping {} does not belong to org {}", mappingKey, orgKey);
            throw new ResourceNotFoundException("Department mapping not found: " + mappingKey);
        }
        return entity;
    }
}
