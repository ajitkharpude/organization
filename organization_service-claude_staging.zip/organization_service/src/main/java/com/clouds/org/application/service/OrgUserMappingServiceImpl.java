package com.clouds.org.application.service;

import com.clouds.org.api.mapper.OrgUserMappingMapper;
import com.clouds.org.api.response.OrgUserMappingResponseDTO;
import com.clouds.org.application.exception.ResourceNotFoundException;
import com.clouds.org.application.port.OrgUserMappingService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.infrastructure.persistence.entity.OrgUserMappingEntity;
import com.clouds.org.infrastructure.persistence.repository.DeptUserMappingRepository;
import com.clouds.org.infrastructure.persistence.repository.OrgUserMappingRepository;
import com.clouds.org.infrastructure.persistence.spec.OrgUserMappingSpecifications;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrgUserMappingServiceImpl implements OrgUserMappingService {

    private static final String SYSTEM_ACTOR = "system";

    private final OrgUserMappingRepository orgMappingRepository;
    private final DeptUserMappingRepository deptMappingRepository;
    private final OrgUserMappingMapper orgUserMappingMapper;

    @Override
    @Transactional(readOnly = true)
    public OrgUserMappingResponseDTO get(String orgKey, String mappingKey) {
        log.debug("Fetching org mapping key={} org={}", mappingKey, orgKey);
        return orgUserMappingMapper.toResponse(loadActiveForOrg(orgKey, mappingKey));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OrgUserMappingResponseDTO> search(String orgKey, String email, Pageable pageable) {
        log.debug("Searching org mappings org={} email={} page={}", orgKey, email, pageable.getPageNumber());
        Specification<OrgUserMappingEntity> spec = OrgUserMappingSpecifications.activeStatus(ActiveStatus.ACTIVE)
                .and(OrgUserMappingSpecifications.orgProjectId(orgKey))
                .and(OrgUserMappingSpecifications.officialEmailContains(email));
        Page<OrgUserMappingResponseDTO> result =
                orgMappingRepository.findAll(spec, pageable).map(orgUserMappingMapper::toResponse);
        log.debug("Org mapping search result: org={} total={}", orgKey, result.getTotalElements());
        return result;
    }

    @Override
    @Transactional
    public void removeUserFromOrg(String orgKey, String mappingKey) {
        log.info("Removing user from org: mappingKey={} org={}", mappingKey, orgKey);
        OrgUserMappingEntity entity = loadActiveForOrg(orgKey, mappingKey);

        entity.setActiveStatus(ActiveStatus.DELETED);
        entity.setIsActive(0);
        entity.setLastModifiedBy(SYSTEM_ACTOR);
        entity.setRemovedBy(SYSTEM_ACTOR);
        entity.setRemovedOn(OffsetDateTime.now());
        orgMappingRepository.save(entity);

        // Cascade: a user removed from the org no longer belongs to any of
        // that org's departments either.
        int deptMappingsCleared = deptMappingRepository.softDeleteAllForUserInOrg(
                entity.getOfficialEmail(), orgKey, ActiveStatus.ACTIVE, ActiveStatus.DELETED, SYSTEM_ACTOR);

        log.info("User removed from org: mappingKey={} org={} email={} deptMappingsCleared={}",
                mappingKey, orgKey, entity.getOfficialEmail(), deptMappingsCleared);
    }

    private OrgUserMappingEntity loadActiveForOrg(String orgKey, String mappingKey) {
        OrgUserMappingEntity entity = orgMappingRepository
                .findByKeyValAndActiveStatus(mappingKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("Org mapping not found: " + mappingKey));

        if (!orgKey.equals(entity.getOrgProjectId())) {
            log.warn("Org mapping {} does not belong to org {}", mappingKey, orgKey);
            throw new ResourceNotFoundException("Org mapping not found: " + mappingKey);
        }
        return entity;
    }
}
