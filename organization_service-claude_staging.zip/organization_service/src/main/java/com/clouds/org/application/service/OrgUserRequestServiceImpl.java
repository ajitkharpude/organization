package com.clouds.org.application.service;

import com.clouds.org.api.mapper.OrgUserRequestMapper;
import com.clouds.org.api.request.ApproveRequestDTO;
import com.clouds.org.api.request.OrgUserRequestDTO;
import com.clouds.org.api.response.OrgUserRequestResponseDTO;
import com.clouds.org.application.exception.DuplicateResourceException;
import com.clouds.org.application.exception.InvalidRequestException;
import com.clouds.org.application.exception.ResourceNotFoundException;
import com.clouds.org.application.port.OrgUserRequestService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.domain.RequestStatus;
import com.clouds.org.infrastructure.persistence.entity.OrgUserMappingEntity;
import com.clouds.org.infrastructure.persistence.entity.OrgUserRequestEntity;
import com.clouds.org.infrastructure.persistence.repository.OrgUserMappingRepository;
import com.clouds.org.infrastructure.persistence.repository.OrgUserRequestRepository;
import com.clouds.org.infrastructure.persistence.repository.OrganizationRepository;
import com.clouds.org.infrastructure.persistence.spec.OrgUserRequestSpecifications;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrgUserRequestServiceImpl implements OrgUserRequestService {

    private static final String SYSTEM_ACTOR = "system";
    private static final String SELF_ACTOR = "self";
    private static final int IS_ACTIVE = 1;

    private final OrgUserRequestRepository requestRepository;
    private final OrgUserMappingRepository mappingRepository;
    private final OrganizationRepository organizationRepository;
    private final OrgUserRequestMapper requestMapper;

    @Override
    @Transactional
    public OrgUserRequestResponseDTO createRequest(String orgKey, OrgUserRequestDTO request) {
        log.info("Creating org-user request org={} email={}", orgKey, request.getOfficialEmail());
        requireActiveOrg(orgKey);

        if (requestRepository.existsByOrgProjectIdAndOfficialEmailAndRequestStatusAndActiveStatus(
                orgKey, request.getOfficialEmail(), RequestStatus.PENDING, ActiveStatus.ACTIVE)) {
            log.warn("Duplicate pending request for {} in org {}", request.getOfficialEmail(), orgKey);
            throw new DuplicateResourceException(
                    "A pending request already exists for this email and organization");
        }

        OrgUserRequestEntity entity = requestMapper.toEntity(request);
        entity.setKeyVal(UUID.randomUUID().toString());
        entity.setOrgProjectId(orgKey);
        entity.setRequestStatus(RequestStatus.PENDING);
        entity.setActiveStatus(ActiveStatus.ACTIVE);
        entity.setCreatedBy(request.getOfficialEmail());
        entity.setLastModifiedBy(request.getOfficialEmail());

        try {
            // saveAndFlush so a concurrent duplicate (the race the application-layer
            // check above can't fully close) still surfaces here via the DB's partial
            // unique index, rather than slipping through.
            OrgUserRequestEntity saved = requestRepository.saveAndFlush(entity);
            log.info("Org-user request created: key={} org={} email={}", saved.getKeyVal(), orgKey, request.getOfficialEmail());
            return requestMapper.toResponse(saved);
        } catch (DataIntegrityViolationException ex) {
            log.warn("Duplicate pending request for {} in org {}", request.getOfficialEmail(), orgKey);
            throw new DuplicateResourceException(
                    "A pending request already exists for this email and organization");
        }
    }

    @Override
    @Transactional
    public OrgUserRequestResponseDTO approve(String orgKey, String requestKey, ApproveRequestDTO request) {
        log.info("Approving org-user request key={} org={}", requestKey, orgKey);
        OrgUserRequestEntity entity = loadPending(orgKey, requestKey);

        String actor = request != null && StringUtils.hasText(request.getActionedBy())
                ? request.getActionedBy() : SYSTEM_ACTOR;
        String roleId = request != null ? request.getPrimaryRoleId() : null;

        entity.setRequestStatus(RequestStatus.APPROVED);
        entity.setActionedBy(actor);
        entity.setActionedOn(LocalDateTime.now());
        entity.setLastModifiedBy(actor);
        OrgUserRequestEntity saved = requestRepository.save(entity);

        OrgUserMappingEntity mapping = new OrgUserMappingEntity();
        mapping.setKeyVal(UUID.randomUUID().toString());
        mapping.setOrgProjectId(orgKey);
        mapping.setOfficialEmail(entity.getOfficialEmail());
        mapping.setPrimaryRoleId(roleId);
        mapping.setIsActive(IS_ACTIVE);
        mapping.setActiveStatus(ActiveStatus.ACTIVE);
        mapping.setCreatedBy(actor);
        mapping.setLastModifiedBy(actor);
        mappingRepository.save(mapping);

        log.info("Org-user request approved: key={} org={} actionedBy={}", requestKey, orgKey, actor);
        return requestMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public OrgUserRequestResponseDTO reject(String orgKey, String requestKey) {
        log.info("Rejecting org-user request key={} org={}", requestKey, orgKey);
        OrgUserRequestEntity entity = loadPending(orgKey, requestKey);
        entity.setRequestStatus(RequestStatus.REJECTED);
        entity.setActionedBy(SYSTEM_ACTOR);
        entity.setActionedOn(LocalDateTime.now());
        entity.setLastModifiedBy(SYSTEM_ACTOR);
        log.info("Org-user request rejected: key={} org={}", requestKey, orgKey);
        return requestMapper.toResponse(requestRepository.save(entity));
    }

    @Override
    @Transactional
    public OrgUserRequestResponseDTO cancel(String orgKey, String requestKey) {
        log.info("Cancelling org-user request key={} org={}", requestKey, orgKey);
        OrgUserRequestEntity entity = loadPending(orgKey, requestKey);
        entity.setRequestStatus(RequestStatus.CANCELLED);
        entity.setActionedBy(SELF_ACTOR);
        entity.setActionedOn(LocalDateTime.now());
        entity.setLastModifiedBy(SELF_ACTOR);
        log.info("Org-user request cancelled: key={} org={}", requestKey, orgKey);
        return requestMapper.toResponse(requestRepository.save(entity));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OrgUserRequestResponseDTO> search(String orgKey, Integer status, String email, Pageable pageable) {
        log.debug("Searching org-user requests org={} status={} email={} page={}", orgKey, status, email, pageable.getPageNumber());
        Specification<OrgUserRequestEntity> spec = OrgUserRequestSpecifications.activeStatus(ActiveStatus.ACTIVE)
                .and(OrgUserRequestSpecifications.orgProjectId(orgKey))
                .and(OrgUserRequestSpecifications.requestStatus(status))
                .and(OrgUserRequestSpecifications.officialEmailContains(email));
        Page<OrgUserRequestResponseDTO> result = requestRepository.findAll(spec, pageable).map(requestMapper::toResponse);
        log.debug("Org-user request search result: org={} total={}", orgKey, result.getTotalElements());
        return result;
    }

    private void requireActiveOrg(String orgKey) {
        organizationRepository.findByKeyValAndActiveStatus(orgKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found: " + orgKey));
    }

    /**
     * Loads a request scoped to the org and asserts it is still pending.
     */
    private OrgUserRequestEntity loadPending(String orgKey, String requestKey) {
        OrgUserRequestEntity entity = requestRepository
                .findByKeyValAndActiveStatus(requestKey, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + requestKey));

        if (!orgKey.equals(entity.getOrgProjectId())) {
            log.warn("Request {} does not belong to org {}", requestKey, orgKey);
            throw new ResourceNotFoundException("Request not found: " + requestKey);
        }

        if (!Integer.valueOf(RequestStatus.PENDING).equals(entity.getRequestStatus())) {
            log.warn("Invalid status transition for request {}: current status {}",
                    requestKey, entity.getRequestStatus());
            throw new InvalidRequestException("Request is not in a pending state");
        }
        return entity;
    }
}
