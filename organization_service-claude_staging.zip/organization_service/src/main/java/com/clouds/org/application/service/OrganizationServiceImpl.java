package com.clouds.org.application.service;

import com.clouds.org.api.mapper.OrganizationMapper;
import com.clouds.org.api.request.OrgRequestDTO;
import com.clouds.org.api.response.OrgResponseDTO;
import com.clouds.org.application.exception.DuplicateResourceException;
import com.clouds.org.application.exception.ForbiddenException;
import com.clouds.org.application.exception.ResourceNotFoundException;
import com.clouds.org.application.port.OrganizationService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.domain.WizardType;
import com.clouds.org.infrastructure.config.EvokeProperties;
import com.clouds.org.infrastructure.persistence.entity.OrganizationEntity;
import com.clouds.org.infrastructure.persistence.entity.WizardEntity;
import com.clouds.org.infrastructure.persistence.repository.OrganizationRepository;
import com.clouds.org.infrastructure.persistence.repository.WizardRepository;
import com.clouds.org.infrastructure.persistence.spec.OrganizationSpecifications;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationServiceImpl implements OrganizationService {

    private static final String SYSTEM_ACTOR = "system";

    private final OrganizationRepository organizationRepository;
    private final WizardRepository wizardRepository;
    private final OrganizationMapper organizationMapper;
    private final EvokeProperties properties;

    @Override
    @Transactional
    public OrgResponseDTO create(OrgRequestDTO request) {
        log.info("Creating organization: orgWebSite={}", request.getOrgWebSite());
        ensureWebSiteUnique(request.getOrgWebSite(), null);

        OrganizationEntity org = organizationMapper.toEntity(request);
        org.setKeyVal(UUID.randomUUID().toString());
        org.setOrgProjectId(properties.getSuperOrgId());
        org.setParentOrgId(properties.getSuperOrgId());
        org.setRefId(resolveOrgWizardRefId(properties.getSuperOrgId()));
        org.setActiveStatus(ActiveStatus.ACTIVE);
        org.setCreatedBy(SYSTEM_ACTOR);
        org.setLastModifiedBy(SYSTEM_ACTOR);

        OrgResponseDTO result = organizationMapper.toResponse(organizationRepository.save(org));
        log.info("Organization created: key={}", result.getKeyVal());
        return result;
    }

    @Override
    @Transactional
    public OrgResponseDTO update(String keyVal, OrgRequestDTO request) {
        log.info("Updating organization: key={}", keyVal);
        guardSuperOrg(keyVal);
        OrganizationEntity org = loadActive(keyVal);

        ensureWebSiteUnique(request.getOrgWebSite(), keyVal);

        organizationMapper.updateEntity(request, org);
        org.setLastModifiedBy(SYSTEM_ACTOR);

        OrgResponseDTO result = organizationMapper.toResponse(organizationRepository.save(org));
        log.info("Organization updated: key={}", keyVal);
        return result;
    }

    @Override
    @Transactional(readOnly = true)
    public OrgResponseDTO getByKeyVal(String keyVal) {
        log.debug("Fetching organization: key={}", keyVal);
        return organizationMapper.toResponse(loadActive(keyVal));
    }

    @Override
    @Transactional
    public void softDelete(String keyVal) {
        log.info("Soft-deleting organization: key={}", keyVal);
        guardSuperOrg(keyVal);
        OrganizationEntity org = loadActive(keyVal);
        org.setActiveStatus(ActiveStatus.DELETED);
        org.setLastModifiedBy(SYSTEM_ACTOR);
        organizationRepository.save(org);
        log.info("Organization soft-deleted: key={}", keyVal);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<OrgResponseDTO> search(String title, Pageable pageable) {
        log.debug("Searching organizations: title={} page={}", title, pageable.getPageNumber());
        Specification<OrganizationEntity> spec = OrganizationSpecifications.activeStatus(ActiveStatus.ACTIVE)
                .and(OrganizationSpecifications.keyValNot(properties.getSuperOrgId()))
                .and(OrganizationSpecifications.titleContains(title));
        Page<OrgResponseDTO> result = organizationRepository.findAll(spec, pageable).map(organizationMapper::toResponse);
        log.debug("Organization search result: total={}", result.getTotalElements());
        return result;
    }

    /**
     * Loads an org that is not soft-deleted. A deleted ({@code active_status=5})
     * or missing row is treated as not found.
     */
    private OrganizationEntity loadActive(String keyVal) {
        OrganizationEntity org = organizationRepository.findById(keyVal)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found: " + keyVal));
        if (Integer.valueOf(ActiveStatus.DELETED).equals(org.getActiveStatus())) {
            throw new ResourceNotFoundException("Organization not found: " + keyVal);
        }
        return org;
    }

    private void guardSuperOrg(String keyVal) {
        if (keyVal != null && keyVal.equals(properties.getSuperOrgId())) {
            log.warn("Blocked mutating operation on super org: {}", keyVal);
            throw new ForbiddenException("The super organization cannot be modified or deleted");
        }
    }

    private void ensureWebSiteUnique(String orgWebSite, String selfKeyVal) {
        if (!StringUtils.hasText(orgWebSite)) {
            return;
        }
        boolean exists = selfKeyVal == null
                ? organizationRepository.existsByOrgWebSiteAndActiveStatus(orgWebSite, ActiveStatus.ACTIVE)
                : organizationRepository.existsByOrgWebSiteAndActiveStatusAndKeyValNot(
                        orgWebSite, ActiveStatus.ACTIVE, selfKeyVal);
        if (exists) {
            log.warn("Duplicate org_web_site rejected: {}", orgWebSite);
            throw new DuplicateResourceException("An organization with this website already exists");
        }
    }

    private String resolveOrgWizardRefId(String orgProjectId) {
        return wizardRepository
                .findFirstByOrgProjectIdAndWizardTypeAndActiveStatus(
                        orgProjectId, WizardType.ORG.name(), ActiveStatus.ACTIVE)
                .map(WizardEntity::getKeyVal)
                .orElseGet(() -> {
                    log.warn("No ORG wizard found for org {}; proceeding with null ref_id", orgProjectId);
                    return null;
                });
    }
}
