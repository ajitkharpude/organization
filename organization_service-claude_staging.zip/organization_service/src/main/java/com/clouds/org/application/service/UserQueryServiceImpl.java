package com.clouds.org.application.service;

import com.clouds.org.api.mapper.UserMapper;
import com.clouds.org.api.response.UserResponseDTO;
import com.clouds.org.application.port.UserQueryService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.infrastructure.persistence.entity.UserEntity;
import com.clouds.org.infrastructure.persistence.repository.UserRepository;
import com.clouds.org.infrastructure.persistence.spec.UserSpecifications;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserQueryServiceImpl implements UserQueryService {

    private final UserRepository userRepository;
    private final UserMapper userMapper;

    @Override
    @Transactional(readOnly = true)
    public Page<UserResponseDTO> search(String firstName, String lastName, String officialEmail,
                                        String personalEmail, String orgKey, Pageable pageable) {
        log.debug("Searching users firstName={} lastName={} officialEmail={} orgKey={} page={}",
                firstName, lastName, officialEmail, orgKey, pageable.getPageNumber());
        Specification<UserEntity> spec = UserSpecifications.activeStatus(ActiveStatus.ACTIVE)
                .and(UserSpecifications.firstNameContains(firstName))
                .and(UserSpecifications.lastNameContains(lastName))
                .and(UserSpecifications.officialEmailContains(officialEmail))
                .and(UserSpecifications.personalEmailContains(personalEmail))
                .and(UserSpecifications.orgProjectId(orgKey));
        Page<UserResponseDTO> result = userRepository.findAll(spec, pageable).map(userMapper::toResponse);
        log.debug("User search result: total={}", result.getTotalElements());
        return result;
    }
}
