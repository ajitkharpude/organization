package com.clouds.org.application.service;

import com.clouds.org.api.mapper.UserMapper;
import com.clouds.org.api.request.UserUpdateRequestDTO;
import com.clouds.org.api.response.UserResponseDTO;
import com.clouds.org.application.exception.ResourceNotFoundException;
import com.clouds.org.application.port.UserService;
import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.domain.RequestStatus;
import com.clouds.org.infrastructure.persistence.entity.UserEntity;
import com.clouds.org.infrastructure.persistence.repository.DeptUserMappingRepository;
import com.clouds.org.infrastructure.persistence.repository.OrgUserMappingRepository;
import com.clouds.org.infrastructure.persistence.repository.OrgUserRequestRepository;
import com.clouds.org.infrastructure.persistence.repository.UserCredentialRepository;
import com.clouds.org.infrastructure.persistence.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private static final String SYSTEM_ACTOR = "system";

    private final UserRepository userRepository;
    private final UserCredentialRepository credentialRepository;
    private final OrgUserMappingRepository orgUserMappingRepository;
    private final DeptUserMappingRepository deptUserMappingRepository;
    private final OrgUserRequestRepository orgUserRequestRepository;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public UserResponseDTO update(String keyVal, UserUpdateRequestDTO request) {
        log.info("Updating user: key={}", keyVal);
        UserEntity user = loadActive(keyVal);

        userMapper.updateEntity(request, user);
        user.setLastModifiedBy(SYSTEM_ACTOR);

        UserResponseDTO result = userMapper.toResponse(userRepository.save(user));
        log.info("User updated: key={}", keyVal);
        return result;
    }

    @Override
    @Transactional
    public void delete(String keyVal) {
        log.info("Deleting user: key={}", keyVal);
        UserEntity user = loadActive(keyVal);
        String officialEmail = user.getOfficialEmail();

        user.setActiveStatus(ActiveStatus.DELETED);
        user.setIsActive(0);
        user.setLastModifiedBy(SYSTEM_ACTOR);
        userRepository.save(user);

        int orgMappingsCleared = orgUserMappingRepository.softDeleteAllForUser(
                officialEmail, ActiveStatus.ACTIVE, ActiveStatus.DELETED, SYSTEM_ACTOR);

        int deptMappingsCleared = deptUserMappingRepository.softDeleteAllForUser(
                officialEmail, ActiveStatus.ACTIVE, ActiveStatus.DELETED, SYSTEM_ACTOR);

        int pendingRequestsCancelled = orgUserRequestRepository.cancelAllPendingForUser(
                officialEmail, ActiveStatus.ACTIVE, RequestStatus.PENDING, RequestStatus.CANCELLED, SYSTEM_ACTOR);

        credentialRepository.softDeleteByContactId(keyVal, ActiveStatus.DELETED);

        log.info("User deleted: key={} email={} orgMappingsCleared={} deptMappingsCleared={} "
                        + "pendingRequestsCancelled={}",
                keyVal, officialEmail, orgMappingsCleared, deptMappingsCleared, pendingRequestsCancelled);
    }

    private UserEntity loadActive(String keyVal) {
        return userRepository.findByKeyValAndActiveStatus(keyVal, ActiveStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + keyVal));
    }
}
