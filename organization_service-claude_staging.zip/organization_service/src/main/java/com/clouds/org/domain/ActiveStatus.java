package com.clouds.org.domain;

/**
 * Soft-delete / lifecycle status codes used across all aggregates.
 * Stored as the raw integer in the {@code active_status} column.
 */
public final class ActiveStatus {

    public static final int ACTIVE = 1;
    public static final int DELETED = 5;
    public static final int ARCHIVED = 9;

    private ActiveStatus() {
    }
}
