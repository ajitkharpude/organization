package com.clouds.org.domain;

/**
 * Lifecycle of an {@code org_user_request}.
 * Stored as the raw integer in the {@code request_status} column.
 */
public final class RequestStatus {

    public static final int PENDING = 0;
    public static final int APPROVED = 1;
    public static final int REJECTED = 2;
    public static final int CANCELLED = 3;

    private RequestStatus() {
    }
}
