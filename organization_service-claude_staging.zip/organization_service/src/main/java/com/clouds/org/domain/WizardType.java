package com.clouds.org.domain;

/**
 * Discriminator for a {@code wizard} row.
 */
public enum WizardType {
    ORG,
    USER,
    ROLE,
    DEPT
}
