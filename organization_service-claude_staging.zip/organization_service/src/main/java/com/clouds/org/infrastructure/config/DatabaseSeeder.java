package com.clouds.org.infrastructure.config;

import com.clouds.org.domain.ActiveStatus;
import com.clouds.org.domain.WizardType;
import com.clouds.org.infrastructure.persistence.entity.OrganizationEntity;
import com.clouds.org.infrastructure.persistence.entity.WizardEntity;
import com.clouds.org.infrastructure.persistence.repository.OrganizationRepository;
import com.clouds.org.infrastructure.persistence.repository.WizardRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Component
@RequiredArgsConstructor
public class DatabaseSeeder implements CommandLineRunner {

    private final OrganizationRepository organizationRepository;
    private final WizardRepository wizardRepository;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void run(String... args) {
        String superOrgKey = "ORG_1001";
        
        if (!organizationRepository.existsById(superOrgKey)) {
            log.warn("Super organization ORG_1001 not found. Seeding initial data...");

            OrganizationEntity superOrg = new OrganizationEntity();
            superOrg.setKeyVal(superOrgKey);
            superOrg.setTitle("Super Organization");
            superOrg.setDescription("Root / parent organization.");
            superOrg.setActiveStatus(ActiveStatus.ACTIVE);
            superOrg.setCreatedBy("system");
            superOrg.setLastModifiedBy("system");
            
            organizationRepository.save(superOrg);
            
            seedWizard("WIZ_ORG_1001", WizardType.ORG, superOrgKey);
            seedWizard("WIZ_USER_1001", WizardType.USER, superOrgKey);
            seedWizard("WIZ_ROLE_1001", WizardType.ROLE, superOrgKey);
            seedWizard("WIZ_DEPT_1001", WizardType.DEPT, superOrgKey);
            
            log.warn("Super organization and wizards seeded successfully.");
        } else {
            log.warn("Super organization ORG_1001 already exists. Skipping seed.");
        }
    }

    private void seedWizard(String keyVal, WizardType type, String orgProjectId) {
        if (!wizardRepository.existsById(keyVal)) {
            WizardEntity wizard = new WizardEntity();
            wizard.setKeyVal(keyVal);
            wizard.setWizardType(type.name());
            wizard.setTitle(type.name() + " Wizard");
            wizard.setRefId(orgProjectId);
            wizard.setOrgProjectId(orgProjectId);
            wizard.setActiveStatus(ActiveStatus.ACTIVE);
            wizard.setCreatedBy("system");
            wizard.setLastModifiedBy("system");
            wizardRepository.save(wizard);
        }
    }
}
