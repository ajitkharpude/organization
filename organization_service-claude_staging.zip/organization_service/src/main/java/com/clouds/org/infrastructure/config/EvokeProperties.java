package com.clouds.org.infrastructure.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Strongly-typed binding for {@code evoke.*} configuration.
 */
@ConfigurationProperties(prefix = "evoke")
public class EvokeProperties {

    /** key_val of the pre-seeded super/root organization. */
    private String superOrgId;

    private final Bcrypt bcrypt = new Bcrypt();

    public String getSuperOrgId() {
        return superOrgId;
    }

    public void setSuperOrgId(String superOrgId) {
        this.superOrgId = superOrgId;
    }

    public Bcrypt getBcrypt() {
        return bcrypt;
    }

    public static class Bcrypt {
        /** BCrypt cost factor. */
        private int strength = 12;

        public int getStrength() {
            return strength;
        }

        public void setStrength(int strength) {
            this.strength = strength;
        }
    }
}
