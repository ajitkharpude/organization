package com.clouds.org.infrastructure.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Custom health indicator exposed at {@code /actuator/health/organizationDb}.
 *
 * <p>Spring Boot's built-in {@code DataSourceHealthIndicator} already covers
 * basic connectivity. This one adds richer diagnostic detail: it reports the
 * PostgreSQL server version and the connection pool validation query result,
 * making it easier to spot partial failures (e.g. pool saturated but ping OK).
 */
@Slf4j
@Component("organizationDb")
@RequiredArgsConstructor
public class OrganizationDbHealthIndicator implements HealthIndicator {

    private static final String VERSION_QUERY  = "SELECT version()";
    private static final String PING_QUERY     = "SELECT 1";

    private final JdbcTemplate jdbcTemplate;

    @Override
    public Health health() {
        try {
            // Verify the connection is alive.
            jdbcTemplate.queryForObject(PING_QUERY, Integer.class);

            // Collect useful diagnostic info for the health response.
            String dbVersion = jdbcTemplate.queryForObject(VERSION_QUERY, String.class);

            return Health.up()
                    .withDetail("database", "PostgreSQL")
                    .withDetail("validationQuery", PING_QUERY)
                    .withDetail("serverVersion", dbVersion)
                    .build();

        } catch (Exception ex) {
            log.error("OrganizationDb health check failed", ex);
            return Health.down()
                    .withDetail("database", "PostgreSQL")
                    .withDetail("error", ex.getMessage())
                    .build();
        }
    }
}
