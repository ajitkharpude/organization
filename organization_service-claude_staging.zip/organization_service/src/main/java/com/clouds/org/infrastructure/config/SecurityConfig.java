package com.clouds.org.infrastructure.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Registers the {@link BCryptPasswordEncoder} used for password hashing and
 * verification. There is deliberately NO Spring Security filter chain, JWT, or
 * authentication wiring — this bean is the only thing pulled from Spring Security.
 */
@Configuration
@EnableConfigurationProperties(EvokeProperties.class)
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder(EvokeProperties properties) {
        return new BCryptPasswordEncoder(properties.getBcrypt().getStrength());
    }
}
