package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "department")
public class DepartmentEntity extends BaseEntity {

    @Id
    @Column(name = "key_val")
    private String keyVal;

    @Column(name = "sub_key_type")
    private String subKeyType;

    @Column(name = "key_type")
    private String keyType;

    @Column(name = "active_status")
    private Integer activeStatus;

    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "org_web_site")
    private String orgWebSite;

    @Column(name = "ref_id")
    private String refId;

    @Column(name = "version")
    private Integer version;

    @Column(name = "image_path")
    private String imagePath;

    @Column(name = "parent_task_id")
    private String parentTaskId;

    @Column(name = "default_obj")
    private Integer defaultObj;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @Column(name = "country_code")
    private String countryCode;

    @Column(name = "continent")
    private String continent;

    @Column(name = "location")
    private String location;

    @Column(name = "latitude")
    private BigDecimal latitude;

    @Column(name = "longitude")
    private BigDecimal longitude;

    @Column(name = "zipcode")
    private String zipcode;

    @Column(name = "timezone")
    private String timezone;

    @Column(name = "org_project_id")
    private String orgProjectId;

    @Column(name = "project_id")
    private String projectId;

    @Column(name = "dept_project_id")
    private String deptProjectId;

    @Column(name = "listing_id")
    private String listingId;
}
