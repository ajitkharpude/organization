package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
@Entity
@Table(name = "dept_user_mapping")
public class DeptUserMappingEntity extends BaseEntity {

    @Id
    @Column(name = "key_val")
    private String keyVal;

    @Column(name = "org_project_id")
    private String orgProjectId;

    @Column(name = "dept_project_id")
    private String deptProjectId;

    @Column(name = "official_email")
    private String officialEmail;

    @Column(name = "primary_role_id")
    private String primaryRoleId;

    /** Role of user in this department: 1=Admin, 2=Viewer, 4=Manager, 5=Agent, 6=Resident */
    @Column(name = "role_type")
    private Integer roleType;

    @Column(name = "is_active")
    private Integer isActive;

    @Column(name = "active_status")
    private Integer activeStatus;

    /** Who removed this user from the department (null if still active). */
    @Column(name = "removed_by")
    private String removedBy;

    /** When this user was removed from the department (null if still active). */
    @Column(name = "removed_on")
    private OffsetDateTime removedOn;
}
