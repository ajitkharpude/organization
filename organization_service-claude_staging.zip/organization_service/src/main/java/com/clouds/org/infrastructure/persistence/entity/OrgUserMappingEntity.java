package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
@Entity
@Table(name = "org_user_mapping")
public class OrgUserMappingEntity extends BaseEntity {

    @Id
    @Column(name = "key_val")
    private String keyVal;

    @Column(name = "org_project_id")
    private String orgProjectId;

    @Column(name = "official_email")
    private String officialEmail;

    @Column(name = "primary_role_id")
    private String primaryRoleId;

    @Column(name = "is_active")
    private Integer isActive;

    @Column(name = "active_status")
    private Integer activeStatus;

    /** Who removed this user from the org (null if still active). */
    @Column(name = "removed_by")
    private String removedBy;

    /** When this user was removed from the org (null if still active). */
    @Column(name = "removed_on")
    private OffsetDateTime removedOn;
}
