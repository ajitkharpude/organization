package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "org_user_request")
public class OrgUserRequestEntity extends BaseEntity {

    @Id
    @Column(name = "key_val")
    private String keyVal;

    @Column(name = "sub_key_type")
    private String subKeyType;

    @Column(name = "key_type")
    private String keyType;

    @Column(name = "active_status")
    private Integer activeStatus;

    @Column(name = "request_status")
    private Integer requestStatus;

    @Column(name = "official_email")
    private String officialEmail;

    @Column(name = "personal_email")
    private String personalEmail;

    @Column(name = "ref_id")
    private String refId;

    @Column(name = "version")
    private Integer version;

    @Column(name = "org_web_site")
    private String orgWebSite;

    @Column(name = "org_project_id")
    private String orgProjectId;

    @Column(name = "actioned_by")
    private String actionedBy;

    @Column(name = "actioned_on")
    private LocalDateTime actionedOn;
}
