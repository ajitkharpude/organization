package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "organization")
public class OrganizationEntity extends BaseEntity {

    @Id
    @Column(name = "key_val")
    private String keyVal;

    @Column(name = "parent_org_id")
    private String parentOrgId;

    @Column(name = "org_project_id")
    private String orgProjectId;

    @Column(name = "ref_id")
    private String refId;

    @Column(name = "title")
    private String title;

    @Column(name = "active_status")
    private Integer activeStatus;

    @Column(name = "org_web_site")
    private String orgWebSite;

    @Column(name = "org_category")
    private String orgCategory;

    @Column(name = "description")
    private String description;

    @Column(name = "template_id")
    private String templateId;

    @Column(name = "image_path")
    private String imagePath;

    @Column(name = "parent_task_id")
    private String parentTaskId;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @Column(name = "country_code")
    private String countryCode;

    @Column(name = "continent")
    private String continent;

    @Column(name = "location")
    private String location;

    @Column(name = "latitude")
    private BigDecimal latitude;

    @Column(name = "longitude")
    private BigDecimal longitude;

    @Column(name = "zipcode")
    private String zipcode;

    @Column(name = "timezone")
    private String timezone;

    @Column(name = "project_id")
    private String projectId;

    @Column(name = "dept_project_id")
    private String deptProjectId;

    @Column(name = "listing_id")
    private String listingId;

    @Column(name = "show_compare_graph")
    private Integer showCompareGraph;

    @Column(name = "property_sync_to_clouzer")
    private Boolean propertySyncToClouzer;
}
