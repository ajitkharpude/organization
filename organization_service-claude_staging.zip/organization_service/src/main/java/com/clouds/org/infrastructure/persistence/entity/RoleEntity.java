package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "role")
public class RoleEntity extends BaseEntity {

    @Id
    @Column(name = "key_val")
    private String keyVal;

    @Column(name = "sub_key_type")
    private String subKeyType;

    @Column(name = "key_type")
    private String keyType;

    @Column(name = "active_status")
    private Integer activeStatus;

    @Column(name = "title")
    private String title;

    @Column(name = "ref_id")
    private String refId;

    @Column(name = "org_web_site")
    private String orgWebSite;

    @Column(name = "org_project_id")
    private String orgProjectId;

    @Column(name = "dept_project_id")
    private String deptProjectId;
}
