package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Credentials are keyed by {@code official_email}. This table only carries
 * created/last-modified timestamps (no *_by columns), so it manages its own
 * lifecycle timestamps rather than extending {@link BaseEntity}.
 */
@Getter
@Setter
@Entity
@Table(name = "user_credentials")
public class UserCredentialEntity {

    @Id
    @Column(name = "official_email")
    private String officialEmail;

    @Column(name = "sub_key_type")
    private String subKeyType;

    @Column(name = "key_type")
    private String keyType;

    @Column(name = "password")
    private String password;

    @Column(name = "personal_email")
    private String personalEmail;

    @Column(name = "contact_id")
    private String contactId;

    @Column(name = "active_status")
    private Integer activeStatus;

    @Column(name = "created_on")
    private LocalDateTime createdOn;

    @Column(name = "last_modified_on")
    private LocalDateTime lastModifiedOn;

    @PrePersist
    protected void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        this.createdOn = now;
        this.lastModifiedOn = now;
    }

    @PreUpdate
    protected void onUpdate() {
        this.lastModifiedOn = LocalDateTime.now();
    }
}
