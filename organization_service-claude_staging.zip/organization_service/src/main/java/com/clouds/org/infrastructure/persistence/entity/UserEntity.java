package com.clouds.org.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "users")
public class UserEntity extends BaseEntity {

    @Id
    @Column(name = "key_val")
    private String keyVal;

    @Column(name = "key_type")
    private String keyType;

    @Column(name = "sub_key_type")
    private String subKeyType;

    @Column(name = "domain_user_id")
    private String domainUserId;

    @Column(name = "domain")
    private String domain;

    @Column(name = "ref_id")
    private String refId;

    @Column(name = "active_status")
    private Integer activeStatus;

    @Column(name = "is_active")
    private Integer isActive;

    @Column(name = "is_super_admin")
    private Integer isSuperAdmin;

    @Column(name = "version")
    private Integer version;

    @Column(name = "type")
    private Integer type; 

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "middle_name")
    private String middleName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "official_email")
    private String officialEmail;

    @Column(name = "personal_email")
    private String personalEmail;

    @Column(name = "contact_number")
    private String contactNumber;

    @Column(name = "employee_id", insertable = false, updatable = false)
    private Long employeeId;
    
    @Column(name = "primary_role_id")
    private String primaryRoleId;

    @Column(name = "user_image")
    private String userImage;

    @Column(name = "dial_code")
    private String dialCode;

    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "org_web_site")
    private String orgWebSite;

    @Column(name = "org_logo")
    private String orgLogo;

    @Column(name = "image_path")
    private String imagePath;

    @Column(name = "org_project_id")
    private String orgProjectId;

    @Column(name = "dept_project_id")
    private String deptProjectId;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @Column(name = "country_code")
    private String countryCode;

    @Column(name = "continent")
    private String continent;

    @Column(name = "location")
    private String location;

    @Column(name = "latitude")
    private BigDecimal latitude;

    @Column(name = "longitude")
    private BigDecimal longitude;

    @Column(name = "zipcode")
    private String zipcode;

    @Column(name = "timezone")
    private String timezone;
}
