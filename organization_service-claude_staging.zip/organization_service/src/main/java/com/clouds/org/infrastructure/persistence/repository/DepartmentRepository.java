package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.DepartmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DepartmentRepository
        extends JpaRepository<DepartmentEntity, String>,
        JpaSpecificationExecutor<DepartmentEntity> {

    Optional<DepartmentEntity> findByKeyValAndActiveStatus(String keyVal, Integer activeStatus);

    Optional<DepartmentEntity> findByKeyValAndOrgProjectIdAndActiveStatus(
            String keyVal, String orgProjectId, Integer activeStatus);

    List<DepartmentEntity> findByOrgProjectIdAndActiveStatus(String orgProjectId, Integer activeStatus);

    /**
     * Clears the default flag on every active department of an org. Used when a
     * new/updated department is being promoted to the default within the same
     * transaction. {@code keyValToExclude} skips the row being saved.
     */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE DepartmentEntity d SET d.defaultObj = 0, d.lastModifiedOn = CURRENT_TIMESTAMP "
            + "WHERE d.orgProjectId = :orgProjectId AND d.activeStatus = 1 "
            + "AND d.defaultObj = 1 AND d.keyVal <> :keyValToExclude")
    int clearDefaultForOrg(@Param("orgProjectId") String orgProjectId,
                           @Param("keyValToExclude") String keyValToExclude);
}
