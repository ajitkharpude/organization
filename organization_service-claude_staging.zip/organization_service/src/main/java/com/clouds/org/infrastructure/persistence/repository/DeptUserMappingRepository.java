package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.DeptUserMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DeptUserMappingRepository
        extends JpaRepository<DeptUserMappingEntity, String>,
        JpaSpecificationExecutor<DeptUserMappingEntity> {

    Optional<DeptUserMappingEntity> findByKeyValAndActiveStatus(String keyVal, int activeStatus);

    /**
     * Soft-deletes all active dept-user mappings for a given email within an org.
     * Called when a user is removed from an org (cascade) or when a user is deleted.
     */
    @Modifying
    @Query("""
            UPDATE DeptUserMappingEntity m
               SET m.activeStatus = :newStatus,
                   m.isActive = 0,
                   m.lastModifiedBy = :actor,
                   m.removedBy = :actor
             WHERE m.officialEmail = :email
               AND m.orgProjectId = :orgKey
               AND m.activeStatus = :currentStatus
            """)
    int softDeleteAllForUserInOrg(
            @Param("email") String email,
            @Param("orgKey") String orgKey,
            @Param("currentStatus") int currentStatus,
            @Param("newStatus") int newStatus,
            @Param("actor") String actor);

    /**
     * Soft-deletes all active dept-user mappings for a given email across all orgs.
     * Used when deleting a user.
     */
    @Modifying
    @Query("""
            UPDATE DeptUserMappingEntity m
               SET m.activeStatus = :newStatus,
                   m.isActive = 0,
                   m.lastModifiedBy = :actor,
                   m.removedBy = :actor
             WHERE m.officialEmail = :email
               AND m.activeStatus = :currentStatus
            """)
    int softDeleteAllForUser(
            @Param("email") String email,
            @Param("currentStatus") int currentStatus,
            @Param("newStatus") int newStatus,
            @Param("actor") String actor);

    /**
     * Used to enforce the "one active mapping per email per dept" rule at the
     * application layer. The production schema enforces this via a partial unique
     * index (WHERE active_status = 1), but H2 (used in tests) does not support
     * partial unique indexes, so this check is the authoritative engine-agnostic guard.
     */
    boolean existsByDeptProjectIdAndOfficialEmailAndActiveStatus(
            String deptProjectId, String officialEmail, int activeStatus);

}
// NOTE: appended by fix — this closing brace removes the old one, so we add before it
