package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.OrgUserMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrgUserMappingRepository
        extends JpaRepository<OrgUserMappingEntity, String>,
        JpaSpecificationExecutor<OrgUserMappingEntity> {

    Optional<OrgUserMappingEntity> findByKeyValAndActiveStatus(String keyVal, int activeStatus);

    /**
     * Soft-deletes all active org-user mappings for a given email.
     * Used when deleting a user to cascade-remove their org memberships.
     */
    @Modifying
    @Query("""
            UPDATE OrgUserMappingEntity m
               SET m.activeStatus = :newStatus,
                   m.isActive = 0,
                   m.lastModifiedBy = :actor,
                   m.removedBy = :actor
             WHERE m.officialEmail = :email
               AND m.activeStatus = :currentStatus
            """)
    int softDeleteAllForUser(
            @Param("email") String email,
            @Param("currentStatus") int currentStatus,
            @Param("newStatus") int newStatus,
            @Param("actor") String actor);
}
