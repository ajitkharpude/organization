package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.OrgUserRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrgUserRequestRepository
        extends JpaRepository<OrgUserRequestEntity, String>,
        JpaSpecificationExecutor<OrgUserRequestEntity> {

    Optional<OrgUserRequestEntity> findByKeyValAndActiveStatus(String keyVal, Integer activeStatus);

    /**
     * Used to enforce the "one pending request per email per org" rule at the
     * application layer. The production schema also enforces this via a
     * Postgres partial unique index ({@code WHERE request_status = 0}), but
     * that index type isn't supported on every database engine (notably H2,
     * used in tests), so this check is the rule's authoritative, engine-agnostic
     * enforcement point — the DB constraint remains as defense-in-depth.
     */
    boolean existsByOrgProjectIdAndOfficialEmailAndRequestStatusAndActiveStatus(
            String orgProjectId, String officialEmail, Integer requestStatus, Integer activeStatus);

    /**
     * Cancels all pending requests for a given email (used on user delete cascade).
     */
    @Modifying
    @Query("""
            UPDATE OrgUserRequestEntity r
               SET r.requestStatus = :newStatus,
                   r.lastModifiedBy = :actor
             WHERE r.officialEmail = :email
               AND r.activeStatus = :activeStatus
               AND r.requestStatus = :currentStatus
            """)
    int cancelAllPendingForUser(
            @Param("email") String email,
            @Param("activeStatus") int activeStatus,
            @Param("currentStatus") int currentStatus,
            @Param("newStatus") int newStatus,
            @Param("actor") String actor);
}
