package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.OrganizationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrganizationRepository
        extends JpaRepository<OrganizationEntity, String>,
        JpaSpecificationExecutor<OrganizationEntity> {

    Optional<OrganizationEntity> findByKeyValAndActiveStatus(String keyVal, Integer activeStatus);

    boolean existsByOrgWebSiteAndActiveStatus(String orgWebSite, Integer activeStatus);

    boolean existsByOrgWebSiteAndActiveStatusAndKeyValNot(String orgWebSite, Integer activeStatus, String keyVal);
}
