package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.RoleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository
        extends JpaRepository<RoleEntity, String>,
        JpaSpecificationExecutor<RoleEntity> {
}
