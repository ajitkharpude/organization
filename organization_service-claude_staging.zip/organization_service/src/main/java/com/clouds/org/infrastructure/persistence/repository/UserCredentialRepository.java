package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.UserCredentialEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserCredentialRepository
        extends JpaRepository<UserCredentialEntity, String>,
        JpaSpecificationExecutor<UserCredentialEntity> {

    boolean existsByPersonalEmail(String personalEmail);

    @Modifying
    @Query("UPDATE UserCredentialEntity c SET c.activeStatus = :newStatus WHERE c.contactId = :contactId")
    int softDeleteByContactId(@Param("contactId") String contactId, @Param("newStatus") int newStatus);
}
