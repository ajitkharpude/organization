package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository
        extends JpaRepository<UserEntity, String>,
        JpaSpecificationExecutor<UserEntity> {

    boolean existsByOfficialEmail(String officialEmail);

    boolean existsByPersonalEmail(String personalEmail);

    Optional<UserEntity> findByOfficialEmail(String officialEmail);

    Optional<UserEntity> findByKeyValAndActiveStatus(String keyVal, int activeStatus);
}
