package com.clouds.org.infrastructure.persistence.repository;

import com.clouds.org.infrastructure.persistence.entity.WizardEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WizardRepository
        extends JpaRepository<WizardEntity, String>,
        JpaSpecificationExecutor<WizardEntity> {

    Optional<WizardEntity> findFirstByOrgProjectIdAndWizardTypeAndActiveStatus(
            String orgProjectId, String wizardType, Integer activeStatus);
}
