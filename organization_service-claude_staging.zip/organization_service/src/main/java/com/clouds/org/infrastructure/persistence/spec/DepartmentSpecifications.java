package com.clouds.org.infrastructure.persistence.spec;

import com.clouds.org.infrastructure.persistence.entity.DepartmentEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

public final class DepartmentSpecifications {

    private DepartmentSpecifications() {
    }

    public static Specification<DepartmentEntity> activeStatus(int status) {
        return (root, query, cb) -> cb.equal(root.get("activeStatus"), status);
    }

    public static Specification<DepartmentEntity> orgProjectId(String orgProjectId) {
        return (root, query, cb) -> cb.equal(root.get("orgProjectId"), orgProjectId);
    }

    public static Specification<DepartmentEntity> titleContains(String title) {
        if (!StringUtils.hasText(title)) {
            return null;
        }
        return (root, query, cb) ->
                cb.like(cb.lower(root.get("title")), "%" + title.toLowerCase() + "%");
    }
}
