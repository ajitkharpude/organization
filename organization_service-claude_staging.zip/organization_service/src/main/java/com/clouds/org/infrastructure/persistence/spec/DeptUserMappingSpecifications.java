package com.clouds.org.infrastructure.persistence.spec;

import com.clouds.org.infrastructure.persistence.entity.DeptUserMappingEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

public final class DeptUserMappingSpecifications {

    private DeptUserMappingSpecifications() {
    }

    public static Specification<DeptUserMappingEntity> activeStatus(int status) {
        return (root, query, cb) -> cb.equal(root.get("activeStatus"), status);
    }

    public static Specification<DeptUserMappingEntity> orgProjectId(String orgProjectId) {
        if (!StringUtils.hasText(orgProjectId)) {
            return null;
        }
        return (root, query, cb) -> cb.equal(root.get("orgProjectId"), orgProjectId);
    }

    public static Specification<DeptUserMappingEntity> deptProjectId(String deptProjectId) {
        if (!StringUtils.hasText(deptProjectId)) {
            return null;
        }
        return (root, query, cb) -> cb.equal(root.get("deptProjectId"), deptProjectId);
    }

    public static Specification<DeptUserMappingEntity> officialEmailContains(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return (root, query, cb) ->
                cb.like(cb.lower(root.get("officialEmail")), "%" + value.toLowerCase() + "%");
    }
}
