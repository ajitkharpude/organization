package com.clouds.org.infrastructure.persistence.spec;

import com.clouds.org.infrastructure.persistence.entity.OrgUserMappingEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

public final class OrgUserMappingSpecifications {

    private OrgUserMappingSpecifications() {
    }

    public static Specification<OrgUserMappingEntity> activeStatus(int status) {
        return (root, query, cb) -> cb.equal(root.get("activeStatus"), status);
    }

    public static Specification<OrgUserMappingEntity> orgProjectId(String orgProjectId) {
        if (!StringUtils.hasText(orgProjectId)) {
            return null;
        }
        return (root, query, cb) -> cb.equal(root.get("orgProjectId"), orgProjectId);
    }

    public static Specification<OrgUserMappingEntity> officialEmailContains(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return (root, query, cb) ->
                cb.like(cb.lower(root.get("officialEmail")), "%" + value.toLowerCase() + "%");
    }
}
