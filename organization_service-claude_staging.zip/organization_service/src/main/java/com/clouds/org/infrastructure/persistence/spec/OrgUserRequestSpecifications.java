package com.clouds.org.infrastructure.persistence.spec;

import com.clouds.org.infrastructure.persistence.entity.OrgUserRequestEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

public final class OrgUserRequestSpecifications {

    private OrgUserRequestSpecifications() {
    }

    public static Specification<OrgUserRequestEntity> activeStatus(int status) {
        return (root, query, cb) -> cb.equal(root.get("activeStatus"), status);
    }

    public static Specification<OrgUserRequestEntity> orgProjectId(String orgProjectId) {
        return (root, query, cb) -> cb.equal(root.get("orgProjectId"), orgProjectId);
    }

    public static Specification<OrgUserRequestEntity> requestStatus(Integer status) {
        if (status == null) {
            return null;
        }
        return (root, query, cb) -> cb.equal(root.get("requestStatus"), status);
    }

    public static Specification<OrgUserRequestEntity> officialEmailContains(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return (root, query, cb) ->
                cb.like(cb.lower(root.get("officialEmail")), "%" + value.toLowerCase() + "%");
    }
}
