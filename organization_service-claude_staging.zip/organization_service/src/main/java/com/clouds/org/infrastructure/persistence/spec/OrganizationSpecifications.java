package com.clouds.org.infrastructure.persistence.spec;

import com.clouds.org.infrastructure.persistence.entity.OrganizationEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

public final class OrganizationSpecifications {

    private OrganizationSpecifications() {
    }

    public static Specification<OrganizationEntity> activeStatus(int status) {
        return (root, query, cb) -> cb.equal(root.get("activeStatus"), status);
    }

    public static Specification<OrganizationEntity> titleContains(String title) {
        if (!StringUtils.hasText(title)) {
            return null;
        }
        return (root, query, cb) ->
                cb.like(cb.lower(root.get("title")), "%" + title.toLowerCase() + "%");
    }

    public static Specification<OrganizationEntity> keyValNot(String keyVal) {
        if (!StringUtils.hasText(keyVal)) {
            return null;
        }
        return (root, query, cb) -> cb.notEqual(root.get("keyVal"), keyVal);
    }
}
