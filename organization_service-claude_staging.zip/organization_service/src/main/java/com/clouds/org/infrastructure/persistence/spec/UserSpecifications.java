package com.clouds.org.infrastructure.persistence.spec;

import com.clouds.org.infrastructure.persistence.entity.UserEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

public final class UserSpecifications {

    private UserSpecifications() {
    }

    public static Specification<UserEntity> activeStatus(int status) {
        return (root, query, cb) -> cb.equal(root.get("activeStatus"), status);
    }

    public static Specification<UserEntity> orgProjectId(String orgProjectId) {
        if (!StringUtils.hasText(orgProjectId)) {
            return null;
        }
        return (root, query, cb) -> cb.equal(root.get("orgProjectId"), orgProjectId);
    }

    public static Specification<UserEntity> firstNameContains(String value) {
        return ilike("firstName", value);
    }

    public static Specification<UserEntity> lastNameContains(String value) {
        return ilike("lastName", value);
    }

    public static Specification<UserEntity> officialEmailContains(String value) {
        return ilike("officialEmail", value);
    }

    public static Specification<UserEntity> personalEmailContains(String value) {
        return ilike("personalEmail", value);
    }

    private static Specification<UserEntity> ilike(String field, String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return (root, query, cb) ->
                cb.like(cb.lower(root.get(field)), "%" + value.toLowerCase() + "%");
    }
}
