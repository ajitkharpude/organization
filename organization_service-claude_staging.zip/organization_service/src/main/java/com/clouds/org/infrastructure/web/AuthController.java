package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.ApiResponse;
import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.api.request.LoginRequestDTO;
import com.clouds.org.api.request.RegisterRequestDTO;
import com.clouds.org.api.response.UserResponseDTO;
import com.clouds.org.application.port.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<UserResponseDTO>> register(
            @Valid @RequestBody DataArrayRequest<RegisterRequestDTO> request) {
        RegisterRequestDTO payload = EnvelopeSupport.firstPayload(request);
        UserResponseDTO data = authService.register(payload);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Registration successful", data));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<UserResponseDTO>> login(
            @Valid @RequestBody DataArrayRequest<LoginRequestDTO> request) {
        LoginRequestDTO payload = EnvelopeSupport.firstPayload(request);
        UserResponseDTO data = authService.login(payload);
        return ResponseEntity.ok(ApiResponse.success("Login successful", data));
    }
}
