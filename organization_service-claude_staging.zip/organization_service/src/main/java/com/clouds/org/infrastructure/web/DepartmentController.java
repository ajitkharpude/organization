package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.ApiResponse;
import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.api.common.PageResponse;
import com.clouds.org.api.request.DepartmentRequestDTO;
import com.clouds.org.api.response.DepartmentResponseDTO;
import com.clouds.org.application.port.DepartmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orgs/{org_key}/departments")
@RequiredArgsConstructor
public class DepartmentController {

    private final DepartmentService departmentService;

    @PostMapping
    public ResponseEntity<ApiResponse<DepartmentResponseDTO>> create(
            @PathVariable("org_key") String orgKey,
            @Valid @RequestBody DataArrayRequest<DepartmentRequestDTO> request) {
        DepartmentRequestDTO payload = EnvelopeSupport.firstPayload(request);
        DepartmentResponseDTO data = departmentService.create(orgKey, payload);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Department created successfully", data));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<DepartmentResponseDTO>>> list(
            @PathVariable("org_key") String orgKey,
            @RequestParam(required = false) String title,
            @PageableDefault(size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Page<DepartmentResponseDTO> page = departmentService.search(orgKey, title, pageable);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", PageResponse.from(page)));
    }

    @GetMapping("/{dept_key}")
    public ResponseEntity<ApiResponse<DepartmentResponseDTO>> getOne(
            @PathVariable("org_key") String orgKey,
            @PathVariable("dept_key") String deptKey) {
        DepartmentResponseDTO data = departmentService.get(orgKey, deptKey);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", data));
    }

    @PutMapping("/{dept_key}")
    public ResponseEntity<ApiResponse<DepartmentResponseDTO>> update(
            @PathVariable("org_key") String orgKey,
            @PathVariable("dept_key") String deptKey,
            @Valid @RequestBody DataArrayRequest<DepartmentRequestDTO> request) {
        DepartmentRequestDTO payload = EnvelopeSupport.firstPayload(request);
        DepartmentResponseDTO data = departmentService.update(orgKey, deptKey, payload);
        return ResponseEntity.ok(ApiResponse.success("Department updated successfully", data));
    }

    @DeleteMapping("/{dept_key}")
    public ResponseEntity<ApiResponse<Void>> delete(
            @PathVariable("org_key") String orgKey,
            @PathVariable("dept_key") String deptKey) {
        departmentService.softDelete(orgKey, deptKey);
        return ResponseEntity.ok(ApiResponse.success("Department deleted successfully"));
    }
}
