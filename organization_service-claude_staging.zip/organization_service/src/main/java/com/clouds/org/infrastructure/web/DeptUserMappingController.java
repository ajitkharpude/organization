package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.ApiResponse;
import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.api.common.PageResponse;
import com.clouds.org.api.request.DeptUserMappingRequestDTO;
import com.clouds.org.api.response.DeptUserMappingResponseDTO;
import com.clouds.org.application.port.DeptUserMappingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Flat CRUD surface for department-user mappings (department membership).
 * {@code org_key} is supplied as a query parameter since this resource is
 * not nested under {@code /api/orgs/{org_key}} in the URL.
 */
@RestController
@RequestMapping("/api/dept-users")
@RequiredArgsConstructor
public class DeptUserMappingController {

    private final DeptUserMappingService deptUserMappingService;

    @PostMapping
    public ResponseEntity<ApiResponse<DeptUserMappingResponseDTO>> create(
            @RequestParam("org_key") String orgKey,
            @Valid @RequestBody DataArrayRequest<DeptUserMappingRequestDTO> request) {
        DeptUserMappingRequestDTO payload = EnvelopeSupport.firstPayload(request);
        DeptUserMappingResponseDTO data = deptUserMappingService.create(orgKey, payload);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("User added to department successfully", data));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<DeptUserMappingResponseDTO>>> list(
            @RequestParam("org_key") String orgKey,
            @RequestParam(value = "dept_key", required = false) String deptKey,
            @RequestParam(required = false) String email,
            @PageableDefault(size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Page<DeptUserMappingResponseDTO> page = deptUserMappingService.search(orgKey, deptKey, email, pageable);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", PageResponse.from(page)));
    }

    @GetMapping("/{mapping_key}")
    public ResponseEntity<ApiResponse<DeptUserMappingResponseDTO>> getOne(
            @RequestParam("org_key") String orgKey,
            @PathVariable("mapping_key") String mappingKey) {
        DeptUserMappingResponseDTO data = deptUserMappingService.get(orgKey, mappingKey);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", data));
    }

    @DeleteMapping("/{mapping_key}")
    public ResponseEntity<ApiResponse<Void>> delete(
            @RequestParam("org_key") String orgKey,
            @PathVariable("mapping_key") String mappingKey) {
        deptUserMappingService.removeUserFromDept(orgKey, mappingKey);
        return ResponseEntity.ok(ApiResponse.success("User removed from department successfully"));
    }
}
