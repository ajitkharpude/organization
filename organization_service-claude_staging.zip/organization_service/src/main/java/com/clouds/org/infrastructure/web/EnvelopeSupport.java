package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.application.exception.InvalidRequestException;
import lombok.extern.slf4j.Slf4j;

/**
 * Shared helper for unwrapping the inbound {@link DataArrayRequest} envelope.
 * Only the first element of {@code dataArray} is ever processed.
 */
@Slf4j
final class EnvelopeSupport {

    private EnvelopeSupport() {
    }

    static <T> T firstPayload(DataArrayRequest<T> request) {
        if (request == null || request.getDataArray() == null || request.getDataArray().isEmpty()) {
            if (request != null && request.getRequestId() != null) {
                log.warn("Empty dataArray for requestId: {}", request.getRequestId());
            }
            throw new InvalidRequestException("dataArray must not be null or empty");
        }
        T payload = request.getDataArray().get(0);
        if (payload == null) {
            throw new InvalidRequestException("dataArray must not be null or empty");
        }
        return payload;
    }
}
