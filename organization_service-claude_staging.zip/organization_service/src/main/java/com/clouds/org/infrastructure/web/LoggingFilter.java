package com.clouds.org.infrastructure.web;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * Servlet filter that:
 * <ul>
 *   <li>Generates a unique {@code traceId} for every HTTP request and stores it
 *       in the SLF4J MDC so it appears in every log line for that request thread.</li>
 *   <li>Logs an INBOUND line (method + URI + caller IP) when the request arrives.</li>
 *   <li>Logs an OUTBOUND line (status + elapsed ms) when the response leaves.</li>
 *   <li>Always clears the MDC on the way out — thread pools reuse threads.</li>
 * </ul>
 *
 * <p>Actuator paths ({@code /actuator/**}) are excluded to keep the log quiet
 * during liveness / readiness probes from Kubernetes.
 */
@Slf4j
@Component
@Order(1)
public class LoggingFilter extends OncePerRequestFilter {

    private static final String MDC_TRACE_ID = "traceId";
    private static final String MDC_METHOD    = "httpMethod";
    private static final String MDC_URI       = "requestUri";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {

        String traceId = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
        String method  = request.getMethod();
        String uri     = request.getRequestURI();
        String ip      = resolveClientIp(request);

        MDC.put(MDC_TRACE_ID, traceId);
        MDC.put(MDC_METHOD,   method);
        MDC.put(MDC_URI,      uri);

        // Echo trace ID back so callers can correlate logs.
        response.setHeader("X-Trace-Id", traceId);

        long start = System.currentTimeMillis();
        try {
            log.info(">>> {} {} | ip={}", method, uri, ip);
            chain.doFilter(request, response);
        } finally {
            long elapsed = System.currentTimeMillis() - start;
            int  status  = response.getStatus();

            if (status >= 500) {
                log.error("<<< {} {} | status={} | {}ms", method, uri, status, elapsed);
            } else if (status >= 400) {
                log.warn("<<< {} {} | status={} | {}ms",  method, uri, status, elapsed);
            } else {
                log.info("<<< {} {} | status={} | {}ms",  method, uri, status, elapsed);
            }
            MDC.clear();
        }
    }

    /** Skip verbose logging for actuator probe endpoints. */
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String uri = request.getRequestURI();
        return uri.startsWith("/actuator/health");
    }

    /** Respect X-Forwarded-For from reverse-proxy / load-balancer. */
    private String resolveClientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
