package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.ApiResponse;
import com.clouds.org.api.common.PageResponse;
import com.clouds.org.api.response.OrgUserMappingResponseDTO;
import com.clouds.org.application.port.OrgUserMappingService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Flat read/removal surface for org-user mappings (org membership).
 * Mappings themselves are created indirectly via
 * {@link OrgUserRequestController}'s approve endpoint, which is the only
 * path that should grant org membership.
 */
@RestController
@RequestMapping("/api/org-users")
@RequiredArgsConstructor
public class OrgUserMappingController {

    private final OrgUserMappingService orgUserMappingService;

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<OrgUserMappingResponseDTO>>> list(
            @RequestParam("org_key") String orgKey,
            @RequestParam(required = false) String email,
            @PageableDefault(size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Page<OrgUserMappingResponseDTO> page = orgUserMappingService.search(orgKey, email, pageable);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", PageResponse.from(page)));
    }

    @GetMapping("/{mapping_key}")
    public ResponseEntity<ApiResponse<OrgUserMappingResponseDTO>> getOne(
            @RequestParam("org_key") String orgKey,
            @PathVariable("mapping_key") String mappingKey) {
        OrgUserMappingResponseDTO data = orgUserMappingService.get(orgKey, mappingKey);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", data));
    }

    @DeleteMapping("/{mapping_key}")
    public ResponseEntity<ApiResponse<Void>> delete(
            @RequestParam("org_key") String orgKey,
            @PathVariable("mapping_key") String mappingKey) {
        orgUserMappingService.removeUserFromOrg(orgKey, mappingKey);
        return ResponseEntity.ok(ApiResponse.success(
                "User removed from organization successfully (department mappings cleared too)"));
    }
}
