package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.ApiResponse;
import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.api.common.PageResponse;
import com.clouds.org.api.request.ApproveRequestDTO;
import com.clouds.org.api.request.OrgUserRequestDTO;
import com.clouds.org.api.response.OrgUserRequestResponseDTO;
import com.clouds.org.application.port.OrgUserRequestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orgs/{org_key}/requests")
@RequiredArgsConstructor
public class OrgUserRequestController {

    private final OrgUserRequestService orgUserRequestService;

    @PostMapping
    public ResponseEntity<ApiResponse<OrgUserRequestResponseDTO>> create(
            @PathVariable("org_key") String orgKey,
            @Valid @RequestBody DataArrayRequest<OrgUserRequestDTO> request) {
        OrgUserRequestDTO payload = EnvelopeSupport.firstPayload(request);
        OrgUserRequestResponseDTO data = orgUserRequestService.createRequest(orgKey, payload);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Request submitted successfully", data));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<OrgUserRequestResponseDTO>>> list(
            @PathVariable("org_key") String orgKey,
            @RequestParam(required = false) Integer status,
            @RequestParam(required = false) String email,
            @PageableDefault(size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Page<OrgUserRequestResponseDTO> page = orgUserRequestService.search(orgKey, status, email, pageable);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", PageResponse.from(page)));
    }

    @PatchMapping("/{request_key}/approve")
    public ResponseEntity<ApiResponse<OrgUserRequestResponseDTO>> approve(
            @PathVariable("org_key") String orgKey,
            @PathVariable("request_key") String requestKey,
            @RequestBody(required = false) DataArrayRequest<ApproveRequestDTO> request) {
        ApproveRequestDTO payload = (request == null || request.getDataArray() == null
                || request.getDataArray().isEmpty()) ? null : request.getDataArray().get(0);
        OrgUserRequestResponseDTO data = orgUserRequestService.approve(orgKey, requestKey, payload);
        return ResponseEntity.ok(ApiResponse.success("Request approved successfully", data));
    }

    @PatchMapping("/{request_key}/reject")
    public ResponseEntity<ApiResponse<OrgUserRequestResponseDTO>> reject(
            @PathVariable("org_key") String orgKey,
            @PathVariable("request_key") String requestKey) {
        OrgUserRequestResponseDTO data = orgUserRequestService.reject(orgKey, requestKey);
        return ResponseEntity.ok(ApiResponse.success("Request rejected successfully", data));
    }

    @PatchMapping("/{request_key}/cancel")
    public ResponseEntity<ApiResponse<OrgUserRequestResponseDTO>> cancel(
            @PathVariable("org_key") String orgKey,
            @PathVariable("request_key") String requestKey) {
        OrgUserRequestResponseDTO data = orgUserRequestService.cancel(orgKey, requestKey);
        return ResponseEntity.ok(ApiResponse.success("Request cancelled successfully", data));
    }
}
