package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.ApiResponse;
import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.api.common.PageResponse;
import com.clouds.org.api.request.OrgRequestDTO;
import com.clouds.org.api.response.OrgResponseDTO;
import com.clouds.org.application.port.OrganizationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orgs")
@RequiredArgsConstructor
public class OrganizationController {

    private final OrganizationService organizationService;

    @PostMapping
    public ResponseEntity<ApiResponse<OrgResponseDTO>> create(
            @Valid @RequestBody DataArrayRequest<OrgRequestDTO> request) {
        OrgRequestDTO payload = EnvelopeSupport.firstPayload(request);
        OrgResponseDTO data = organizationService.create(payload);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Organization created successfully", data));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<OrgResponseDTO>>> list(
            @RequestParam(required = false) String title,
            @PageableDefault(size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Page<OrgResponseDTO> page = organizationService.search(title, pageable);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", PageResponse.from(page)));
    }

    @GetMapping("/{key_val}")
    public ResponseEntity<ApiResponse<OrgResponseDTO>> getOne(@PathVariable("key_val") String keyVal) {
        OrgResponseDTO data = organizationService.getByKeyVal(keyVal);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", data));
    }

    @PutMapping("/{key_val}")
    public ResponseEntity<ApiResponse<OrgResponseDTO>> update(
            @PathVariable("key_val") String keyVal,
            @Valid @RequestBody DataArrayRequest<OrgRequestDTO> request) {
        OrgRequestDTO payload = EnvelopeSupport.firstPayload(request);
        OrgResponseDTO data = organizationService.update(keyVal, payload);
        return ResponseEntity.ok(ApiResponse.success("Organization updated successfully", data));
    }

    @DeleteMapping("/{key_val}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable("key_val") String keyVal) {
        organizationService.softDelete(keyVal);
        return ResponseEntity.ok(ApiResponse.success("Organization deleted successfully"));
    }
}
