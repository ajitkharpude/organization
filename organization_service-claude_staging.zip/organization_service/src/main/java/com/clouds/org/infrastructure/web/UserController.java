package com.clouds.org.infrastructure.web;

import com.clouds.org.api.common.ApiResponse;
import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.api.common.PageResponse;
import com.clouds.org.api.request.UserUpdateRequestDTO;
import com.clouds.org.api.response.UserResponseDTO;
import com.clouds.org.application.port.UserQueryService;
import com.clouds.org.application.port.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserQueryService userQueryService;
    private final UserService userService;

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<UserResponseDTO>>> list(
            @RequestParam(required = false) String firstName,
            @RequestParam(required = false) String lastName,
            @RequestParam(required = false) String officialEmail,
            @RequestParam(required = false) String personalEmail,
            @RequestParam(required = false) String orgKey,
            @PageableDefault(size = 10, sort = "createdOn", direction = Sort.Direction.DESC) Pageable pageable) {
        Page<UserResponseDTO> page = userQueryService.search(
                firstName, lastName, officialEmail, personalEmail, orgKey, pageable);
        return ResponseEntity.ok(ApiResponse.success("Fetched successfully", PageResponse.from(page)));
    }

    @PutMapping("/{key_val}")
    public ResponseEntity<ApiResponse<UserResponseDTO>> update(
            @PathVariable("key_val") String keyVal,
            @Valid @RequestBody DataArrayRequest<UserUpdateRequestDTO> request) {
        UserUpdateRequestDTO payload = EnvelopeSupport.firstPayload(request);
        UserResponseDTO data = userService.update(keyVal, payload);
        return ResponseEntity.ok(ApiResponse.success("User updated successfully", data));
    }

    @DeleteMapping("/{key_val}")
    public ResponseEntity<ApiResponse<Void>> delete(
            @PathVariable("key_val") String keyVal) {
        userService.delete(keyVal);
        return ResponseEntity.ok(ApiResponse.success("User deleted successfully"));
    }
}
