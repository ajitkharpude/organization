-- ============================================================
-- V2: Seed the root / super organization (ORG_1001) and its
--     four wizard rows (ORG, USER, ROLE, DEPT).
--
-- The USER wizard is required for user registration — its
-- key_val is stored as ref_id on every new user row.
--
-- All INSERTs use ON CONFLICT DO NOTHING so this migration is
-- safe to re-apply on environments where the rows already exist.
-- ============================================================

-- 1. Root organization
INSERT INTO organization (
    key_val,
    title,
    description,
    active_status,
    created_by,
    last_modified_by
)
VALUES (
    'ORG_1001',
    'Super Organization',
    'Root / parent organization.',
    1,
    'system',
    'system'
)
ON CONFLICT (key_val) DO NOTHING;

-- 2. Wizards for ORG_1001
--    ref_id = org_project_id = ORG_1001 (convention per schema comment)

INSERT INTO wizard (key_val, wizard_type, title, ref_id, org_project_id, active_status, created_by, last_modified_by)
VALUES
    ('WIZ_ORG_1001',  'ORG',  'Org Wizard',  'ORG_1001', 'ORG_1001', 1, 'system', 'system'),
    ('WIZ_USER_1001', 'USER', 'User Wizard', 'ORG_1001', 'ORG_1001', 1, 'system', 'system'),
    ('WIZ_ROLE_1001', 'ROLE', 'Role Wizard', 'ORG_1001', 'ORG_1001', 1, 'system', 'system'),
    ('WIZ_DEPT_1001', 'DEPT', 'Dept Wizard', 'ORG_1001', 'ORG_1001', 1, 'system', 'system')
ON CONFLICT (key_val) DO NOTHING;
