-- ============================================================
-- V3: Allow a user to be re-added to an org/department after
--     being removed.
--
-- org_user_mapping.uq_oum and dept_user_mapping.uq_dum were plain
-- UNIQUE constraints on (org_project_id, official_email) and
-- (dept_project_id, official_email) respectively. Removing a user
-- (soft-delete: active_status = 5) left the row in place, so the
-- constraint permanently blocked re-adding that same user — the
-- same problem org_user_request solved via a partial unique index
-- (see uq_our_pending_email_org in schema.sql). This migration
-- applies the same fix here: drop the plain constraints and
-- replace them with partial unique indexes that only consider
-- active (active_status = 1) rows, so removed memberships no
-- longer block re-creation.
-- ============================================================

ALTER TABLE org_user_mapping DROP CONSTRAINT IF EXISTS uq_oum;

CREATE UNIQUE INDEX IF NOT EXISTS uq_oum_active_email_org
    ON org_user_mapping (org_project_id, official_email)
    WHERE active_status = 1;

ALTER TABLE dept_user_mapping DROP CONSTRAINT IF EXISTS uq_dum;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dum_active_email_dept
    ON dept_user_mapping (dept_project_id, official_email)
    WHERE active_status = 1;
