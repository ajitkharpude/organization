-- ============================================================
-- V4: Schema improvements — recommended ALTERs
--
-- 1. Faster credential lookup index (email + active_status)
-- 2. Failed login tracking columns on user_credentials
-- 3. Soft-delete audit trail on org_user_mapping
-- 4. Soft-delete audit trail on dept_user_mapping
--
-- All changes are additive (IF NOT EXISTS / IF COLUMN NOT EXISTS)
-- so this migration is safe to re-apply on environments where
-- some columns may already exist.
-- ============================================================

-- 1. Faster login lookup: covers WHERE official_email = ? AND active_status = 1
CREATE INDEX IF NOT EXISTS idx_cred_email_status
    ON user_credentials (official_email, active_status);

-- 2. Track failed login attempts and account lock-out expiry
ALTER TABLE user_credentials
    ADD COLUMN IF NOT EXISTS failed_login_attempts INT         DEFAULT 0,
    ADD COLUMN IF NOT EXISTS locked_until          TIMESTAMPTZ DEFAULT NULL;

COMMENT ON COLUMN user_credentials.failed_login_attempts IS 'Number of consecutive failed login attempts since last success.';
COMMENT ON COLUMN user_credentials.locked_until           IS 'Account is locked until this timestamp. NULL means not locked.';

-- 3. Soft-delete audit trail on org_user_mapping
--    Records who removed a user from the org and when.
ALTER TABLE org_user_mapping
    ADD COLUMN IF NOT EXISTS removed_by  TEXT        DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS removed_on  TIMESTAMPTZ DEFAULT NULL;

COMMENT ON COLUMN org_user_mapping.removed_by IS 'Email or key_val of the admin who removed the user from the org.';
COMMENT ON COLUMN org_user_mapping.removed_on IS 'Timestamp when the user was removed from the org.';

-- 4. Soft-delete audit trail on dept_user_mapping
--    Records who removed a user from the department and when.
ALTER TABLE dept_user_mapping
    ADD COLUMN IF NOT EXISTS removed_by  TEXT        DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS removed_on  TIMESTAMPTZ DEFAULT NULL;

COMMENT ON COLUMN dept_user_mapping.removed_by IS 'Email or key_val of the admin who removed the user from the department.';
COMMENT ON COLUMN dept_user_mapping.removed_on IS 'Timestamp when the user was removed from the department.';
