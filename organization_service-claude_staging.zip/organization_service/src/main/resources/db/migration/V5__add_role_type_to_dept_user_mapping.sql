-- ============================================================
-- V5: Add role_type column to dept_user_mapping
--
-- dept_user_mapping previously had no role_type column.
-- The entity now maps this column so users can be assigned
-- specific roles (1=Admin, 2=Viewer, 4=Manager, 5=Agent, 6=Resident)
-- within a department. Default is 2 (Viewer).
-- ============================================================

-- Add the column (safe to re-run: IF NOT EXISTS is valid for ADD COLUMN)
ALTER TABLE dept_user_mapping
    ADD COLUMN IF NOT EXISTS role_type INT NOT NULL DEFAULT 2;

-- Add CHECK constraint only if it does not already exist
-- (PostgreSQL does not support ADD CONSTRAINT IF NOT EXISTS,
--  so we guard it with a DO block querying pg_constraint)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
         WHERE conname = 'chk_dum_role_type'
           AND conrelid = 'dept_user_mapping'::regclass
    ) THEN
        ALTER TABLE dept_user_mapping
            ADD CONSTRAINT chk_dum_role_type
            CHECK (role_type IN (1, 2, 4, 5, 6));
    END IF;
END;
$$;

-- Create index if it does not already exist (IF NOT EXISTS is valid for CREATE INDEX)
CREATE INDEX IF NOT EXISTS idx_dum_role_type ON dept_user_mapping (role_type);

COMMENT ON COLUMN dept_user_mapping.role_type
    IS 'Role of user in this department: 1=Admin, 2=Viewer (default), 4=Manager, 5=Agent, 6=Resident';
