-- ═══════════════════════════════════════════════════════════════════
-- EVOKE PLATFORM — CORRECTED FULL SCHEMA DDL
-- Fixes applied:
--   1. Duplicate timezone columns removed
--   2. wizard_type column + CHECK + unique constraint per org added
--   3. FK from users/role/organization/department.ref_id → wizard.key_val
--   4. Each sub-org gets its own wizard set (org_project_id scoped)
--   5. department linked to wizard via ref_id + FK
--   6. actioned_by / actioned_on added to org_user_request
--   7. parent_org_id explicit self-FK on organization
--   8. Broken comment lines fixed
-- ═══════════════════════════════════════════════════════════════════


-- ═══════════════════════════════════════════
-- TABLE: organization
-- ═══════════════════════════════════════════
CREATE TABLE organization (
    -- Identity
    key_val                     TEXT PRIMARY KEY,
    sub_key_type                TEXT,
    key_type                    TEXT,
    subscribe_key_val           TEXT,

    -- Hierarchy: null = super org, set = sub org
    parent_org_id               TEXT,                           -- FK defined below (self-ref)
    org_project_id              TEXT,                           -- FK → organization.key_val (= parent org's key_val for sub-orgs, NULL for super org)

    -- Status
    active_status               SMALLINT DEFAULT 1,

    -- Organization info
    title                       TEXT,
    description                 TEXT,
    org_category                TEXT,
    org_web_site                TEXT,
    ref_id                      TEXT,                           -- FK → wizard.key_val (org-type wizard of parent)
    version                     INT DEFAULT 1,
    template_id                 TEXT,
    image_path                  TEXT,
    parent_task_id              TEXT,

    -- Location
    city                        TEXT,
    state                       TEXT,
    country                     TEXT,
    country_code                TEXT,
    continent                   TEXT,
    location                    TEXT,
    latitude                    DOUBLE PRECISION,
    longitude                   DOUBLE PRECISION,
    zipcode                     TEXT,
    timezone                    TEXT,                           -- fixed: was duplicated

    -- Project / Department
    project_id                  TEXT,
    dept_project_id             TEXT,
    listing_id                  TEXT,

    -- Display
    show_compare_graph          INT DEFAULT 0,

    -- Sync
    property_sync_to_clouzer    BOOLEAN DEFAULT FALSE,

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON COLUMN organization.active_status   IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';
COMMENT ON COLUMN organization.parent_org_id   IS 'Self-FK to parent org. NULL means this is the super/root org.';
COMMENT ON COLUMN organization.org_project_id  IS 'FK → organization.key_val. For sub-orgs, equals the parent org key_val. NULL for the super/root org.';
COMMENT ON COLUMN organization.ref_id          IS 'FK → wizard.key_val. Points to the ORG-type wizard of the parent org that governs this sub-org.';

ALTER TABLE organization
    ADD CONSTRAINT chk_org_active_status
    CHECK (active_status IN (1, 9, 5));

-- Sub-org's org_project_id = parent org's key_val
ALTER TABLE organization
    ADD CONSTRAINT fk_org_project
    FOREIGN KEY (org_project_id) REFERENCES organization (key_val)
    ON DELETE RESTRICT;

-- ref_id → wizard FK is added after wizard table is created (see bottom of file)

CREATE INDEX idx_org_active_status  ON organization (active_status);
CREATE INDEX idx_org_web_site       ON organization (org_web_site);
CREATE INDEX idx_org_last_modified  ON organization (last_modified_on DESC);
CREATE INDEX idx_org_project        ON organization (project_id);
CREATE INDEX idx_org_org_project    ON organization (org_project_id);
CREATE INDEX idx_org_ref_id         ON organization (ref_id);
CREATE INDEX idx_org_parent_org     ON organization (parent_org_id);


-- ═══════════════════════════════════════════
-- TABLE: wizard
-- ═══════════════════════════════════════════
-- Defined before users/role/department so FK constraints can reference it.
CREATE TABLE wizard (
    -- Identity
    key_val                     TEXT PRIMARY KEY,
    sub_key_type                TEXT,
    key_type                    TEXT,

    -- Status
    active_status               SMALLINT DEFAULT 1,

    -- Wizard classification
    wizard_type                 TEXT NOT NULL,                  -- 'ORG' | 'USER' | 'ROLE' | 'DEPT'

    -- Wizard info
    title                       TEXT,
    ref_id                      TEXT NOT NULL,                  -- = org_project_id (the org this wizard belongs to)
    org_web_site                TEXT,

    -- Organization / Department linkage
    org_project_id              TEXT NOT NULL,                  -- FK → organization.key_val
    dept_project_id             TEXT,                          -- FK → department.key_val (optional)

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW(),

    -- Constraints
    CONSTRAINT fk_wizard_org    FOREIGN KEY (org_project_id)  REFERENCES organization (key_val) ON DELETE RESTRICT
    -- fk_wizard_dept added after department table is created
);

COMMENT ON TABLE  wizard             IS 'Type-descriptor / category gateway for entities within an org. An org can have multiple wizards of the same type.';
COMMENT ON COLUMN wizard.wizard_type IS 'Entity type this wizard governs: ORG, USER, ROLE, DEPT.';
COMMENT ON COLUMN wizard.ref_id      IS 'Equals the org_project_id — the organization this wizard belongs to. Mirrors the pattern used in child entities.';
COMMENT ON COLUMN wizard.active_status IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';

ALTER TABLE wizard
    ADD CONSTRAINT chk_wizard_active_status
    CHECK (active_status IN (1, 9, 5));

ALTER TABLE wizard
    ADD CONSTRAINT chk_wizard_type
    CHECK (wizard_type IN ('ORG', 'USER', 'ROLE', 'DEPT'));

CREATE INDEX idx_wizard_active_status ON wizard (active_status);
CREATE INDEX idx_wizard_org_project   ON wizard (org_project_id);
CREATE INDEX idx_wizard_dept_project  ON wizard (dept_project_id);
CREATE INDEX idx_wizard_ref_id        ON wizard (ref_id);
CREATE INDEX idx_wizard_type          ON wizard (wizard_type);
CREATE INDEX idx_wizard_last_modified ON wizard (last_modified_on DESC);

-- Now that wizard exists, add ref_id FK back on organization
ALTER TABLE organization
    ADD CONSTRAINT fk_org_ref_wizard
    FOREIGN KEY (ref_id) REFERENCES wizard (key_val)
    ON DELETE RESTRICT;


-- ═══════════════════════════════════════════
-- TABLE: users
-- ═══════════════════════════════════════════
CREATE TABLE users (
    -- Identity
    key_val                     TEXT PRIMARY KEY,
    key_type                    TEXT,
    sub_key_type                TEXT,
    domain_user_id              TEXT,
    domain                      TEXT,
    ref_id                      TEXT,                          -- FK → wizard.key_val (USER-type wizard of owning org)

    -- Status
    active_status               SMALLINT DEFAULT 1,            -- Object lifecycle: 1=active, 9=archived, 5=deleted
    is_active                   SMALLINT DEFAULT 1,            -- Account state: 1=active, 0=inactive

    is_super_admin              INT DEFAULT 0,
    version                     INT DEFAULT 1,
    type                        INT,

    -- Personal info
    first_name                  TEXT,
    middle_name                 TEXT,
    last_name                   TEXT,
    official_email              TEXT,
    personal_email              TEXT,
    contact_number              TEXT,
    employee_id                 BIGINT,
    primary_role_id             TEXT,
    user_image                  TEXT,
    dial_code                   TEXT,

    -- Organization info
    title                       TEXT,
    description                 TEXT,
    org_web_site                TEXT,
    org_logo                    TEXT,
    image_path                  TEXT,
    org_project_id              TEXT NOT NULL,                 -- FK → organization.key_val
    dept_project_id             TEXT,

    -- Location
    city                        TEXT,
    state                       TEXT,
    country                     TEXT,
    country_code                TEXT,
    continent                   TEXT,
    location                    TEXT,
    latitude                    DOUBLE PRECISION,
    longitude                   DOUBLE PRECISION,
    zipcode                     TEXT,
    timezone                    TEXT,                          -- fixed: was duplicated

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON COLUMN users.active_status IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';
COMMENT ON COLUMN users.is_active     IS 'User account state: 1=active, 0=inactive';
COMMENT ON COLUMN users.ref_id        IS 'FK → wizard.key_val. Points to the USER-type wizard of the org this user belongs to.';

ALTER TABLE users ADD CONSTRAINT chk_users_active_status CHECK (active_status IN (1, 9, 5));
ALTER TABLE users ADD CONSTRAINT chk_is_active           CHECK (is_active IN (0, 1));

ALTER TABLE users
    ADD CONSTRAINT fk_users_organization
    FOREIGN KEY (org_project_id) REFERENCES organization (key_val)
    ON DELETE RESTRICT;

ALTER TABLE users
    ADD CONSTRAINT fk_users_ref_wizard
    FOREIGN KEY (ref_id) REFERENCES wizard (key_val)
    ON DELETE RESTRICT;

CREATE UNIQUE INDEX idx_users_official_email ON users (official_email);
CREATE UNIQUE INDEX idx_users_personal_email ON users (personal_email);
CREATE INDEX idx_users_active_status         ON users (active_status);
CREATE INDEX idx_users_is_active             ON users (is_active);
CREATE INDEX idx_users_domain                ON users (domain);
CREATE INDEX idx_users_org_project           ON users (org_project_id);
CREATE INDEX idx_users_role                  ON users (primary_role_id);
CREATE INDEX idx_users_ref_id                ON users (ref_id);
CREATE INDEX idx_users_last_modified         ON users (last_modified_on DESC);


-- ═══════════════════════════════════════════
-- TABLE: user_credentials
-- ═══════════════════════════════════════════
CREATE TABLE user_credentials (
    -- Identity
    official_email              TEXT PRIMARY KEY,
    sub_key_type                TEXT,
    key_type                    TEXT,

    -- Security
    password                    TEXT            NOT NULL,       -- bcrypt hashed, never plain text
    personal_email              TEXT            NOT NULL UNIQUE,

    -- Reference
    contact_id                  TEXT            NOT NULL,       -- FK → users.key_val

    -- Status
    active_status               SMALLINT        NOT NULL DEFAULT 1,

    -- Audit
    created_on                  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    last_modified_on            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_credentials_contact
        FOREIGN KEY (contact_id) REFERENCES users (key_val)
        ON DELETE CASCADE,

    CONSTRAINT chk_credentials_active_status
        CHECK (active_status IN (1, 9, 5))
);

COMMENT ON COLUMN user_credentials.official_email IS 'PK — unique username / login handle';
COMMENT ON COLUMN user_credentials.password       IS 'Hashed password (bcrypt) — never store plain text';
COMMENT ON COLUMN user_credentials.contact_id     IS 'References users.key_val — one credential row per user';
COMMENT ON COLUMN user_credentials.active_status  IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';

CREATE UNIQUE INDEX idx_credentials_contact       ON user_credentials (contact_id);
CREATE UNIQUE INDEX idx_credentials_recovery      ON user_credentials (personal_email);
CREATE INDEX        idx_credentials_active_status ON user_credentials (active_status);
CREATE INDEX        idx_credentials_last_modified ON user_credentials (last_modified_on DESC);


-- ═══════════════════════════════════════════
-- TABLE: department
-- ═══════════════════════════════════════════
CREATE TABLE department (
    -- Identity
    key_val                     TEXT PRIMARY KEY,
    sub_key_type                TEXT,
    key_type                    TEXT,

    -- Status
    active_status               SMALLINT DEFAULT 1,

    -- Department info
    title                       TEXT,
    description                 TEXT,
    org_web_site                TEXT,
    ref_id                      TEXT,                          -- FK → wizard.key_val (DEPT-type wizard of owning org)
    version                     INT DEFAULT 1,
    image_path                  TEXT,
    parent_task_id              TEXT,
    default_obj                 INT DEFAULT 0,

    -- Location
    city                        TEXT,
    state                       TEXT,
    country                     TEXT,
    country_code                TEXT,
    continent                   TEXT,
    location                    TEXT,
    latitude                    DOUBLE PRECISION,
    longitude                   DOUBLE PRECISION,
    zipcode                     TEXT,
    timezone                    TEXT,

    -- Organization linkage
    org_project_id              TEXT NOT NULL,                 -- FK → organization.key_val
    project_id                  TEXT,
    dept_project_id             TEXT,
    listing_id                  TEXT,

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE  department              IS 'Departments belonging to an organization; mirrors org lifecycle rules.';
COMMENT ON COLUMN department.active_status IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';
COMMENT ON COLUMN department.org_project_id IS 'FK to parent organization. Never null.';
COMMENT ON COLUMN department.default_obj  IS 'Flag: 0=no, 1=yes — default department for the org.';
COMMENT ON COLUMN department.ref_id       IS 'FK → wizard.key_val. Points to the DEPT-type wizard of the org this department belongs to.';

ALTER TABLE department
    ADD CONSTRAINT chk_dept_active_status
    CHECK (active_status IN (1, 9, 5));

ALTER TABLE department
    ADD CONSTRAINT fk_dept_org
    FOREIGN KEY (org_project_id) REFERENCES organization (key_val)
    ON DELETE RESTRICT;

ALTER TABLE department
    ADD CONSTRAINT fk_dept_ref_wizard
    FOREIGN KEY (ref_id) REFERENCES wizard (key_val)
    ON DELETE RESTRICT;

CREATE INDEX idx_dept_active_status ON department (active_status);
CREATE INDEX idx_dept_org_project   ON department (org_project_id);
CREATE INDEX idx_dept_project       ON department (project_id);
CREATE INDEX idx_dept_ref_id        ON department (ref_id);
CREATE INDEX idx_dept_last_modified ON department (last_modified_on DESC);
CREATE INDEX idx_dept_listing       ON department (listing_id);

-- Now that department exists, add deferred FK on wizard.dept_project_id
ALTER TABLE wizard
    ADD CONSTRAINT fk_wizard_dept
    FOREIGN KEY (dept_project_id) REFERENCES department (key_val)
    ON DELETE RESTRICT;


-- ═══════════════════════════════════════════
-- TABLE: role
-- ═══════════════════════════════════════════
CREATE TABLE role (
    -- Identity
    key_val                     TEXT PRIMARY KEY,
    sub_key_type                TEXT,
    key_type                    TEXT,

    -- Status
    active_status               SMALLINT DEFAULT 1,

    -- Role info
    title                       TEXT,
    ref_id                      TEXT,                          -- FK → wizard.key_val (ROLE-type wizard of owning org)
    org_web_site                TEXT,

    -- Organization / Department linkage
    org_project_id              TEXT NOT NULL,                 -- FK → organization.key_val
    dept_project_id             TEXT,                         -- FK → department.key_val (optional: dept-scoped role)

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW(),

    CONSTRAINT fk_role_org  FOREIGN KEY (org_project_id)  REFERENCES organization (key_val) ON DELETE RESTRICT,
    CONSTRAINT fk_role_dept FOREIGN KEY (dept_project_id) REFERENCES department  (key_val)  ON DELETE RESTRICT
);

COMMENT ON TABLE  role              IS 'Roles scoped to an organization or optionally a department.';
COMMENT ON COLUMN role.active_status IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';
COMMENT ON COLUMN role.ref_id       IS 'FK → wizard.key_val. Points to the ROLE-type wizard of the org this role belongs to.';
COMMENT ON COLUMN role.dept_project_id IS 'Optional. NULL means org-level role; set means dept-scoped role.';

ALTER TABLE role ADD CONSTRAINT chk_role_active_status CHECK (active_status IN (1, 9, 5));

-- Prevent duplicate role titles within the same org
ALTER TABLE role ADD CONSTRAINT uq_role_title_org UNIQUE (org_project_id, title);

ALTER TABLE role
    ADD CONSTRAINT fk_role_ref_wizard
    FOREIGN KEY (ref_id) REFERENCES wizard (key_val)
    ON DELETE RESTRICT;

CREATE INDEX idx_role_active_status ON role (active_status);
CREATE INDEX idx_role_org_project   ON role (org_project_id);
CREATE INDEX idx_role_dept_project  ON role (dept_project_id);
CREATE INDEX idx_role_ref_id        ON role (ref_id);
CREATE INDEX idx_role_last_modified ON role (last_modified_on DESC);


-- ═══════════════════════════════════════════
-- TABLE: org_user_mapping
-- ═══════════════════════════════════════════
CREATE TABLE org_user_mapping (
    -- Identity
    key_val                     TEXT PRIMARY KEY,

    org_project_id              TEXT NOT NULL,                 -- FK → organization.key_val
    official_email              TEXT NOT NULL,

    primary_role_id             TEXT,
    role_type                   INT DEFAULT 2,
    is_active                   SMALLINT DEFAULT 1,
    active_status               SMALLINT DEFAULT 1,

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW(),

    removed_by                  TEXT,
    removed_on                  TIMESTAMPTZ,

    CONSTRAINT fk_oum_org FOREIGN KEY (org_project_id) REFERENCES organization (key_val) ON DELETE RESTRICT
);

COMMENT ON TABLE  org_user_mapping              IS 'Maps a user (by official_email) to an organization with a role.';
COMMENT ON COLUMN org_user_mapping.active_status IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';
COMMENT ON COLUMN org_user_mapping.is_active    IS 'Whether this mapping is currently active: 1=active, 0=inactive';
COMMENT ON COLUMN org_user_mapping.primary_role_id IS 'Role assigned to the user in this organization (references role.key_val).';

ALTER TABLE org_user_mapping ADD CONSTRAINT chk_oum_active_status CHECK (active_status IN (1, 9, 5));
ALTER TABLE org_user_mapping ADD CONSTRAINT chk_oum_is_active     CHECK (is_active IN (0, 1));

CREATE INDEX idx_oum_org_project_id ON org_user_mapping (org_project_id);
CREATE INDEX idx_oum_official_email ON org_user_mapping (official_email);
CREATE INDEX idx_oum_is_active      ON org_user_mapping (is_active);
CREATE INDEX idx_oum_active_status  ON org_user_mapping (active_status);
CREATE INDEX idx_oum_last_modified  ON org_user_mapping (last_modified_on DESC);

-- NOTE: In PostgreSQL production, a partial unique index enforces one active mapping per email per org:
-- CREATE UNIQUE INDEX uq_oum_active_email_org ON org_user_mapping (org_project_id, official_email) WHERE active_status = 1;
-- In H2 (test), uniqueness is enforced at the application layer in OrgUserMappingServiceImpl.


-- ═══════════════════════════════════════════
-- TABLE: dept_user_mapping
-- ═══════════════════════════════════════════
CREATE TABLE dept_user_mapping (
    -- Identity
    key_val                     TEXT PRIMARY KEY,

    org_project_id              TEXT NOT NULL,                 -- FK → organization.key_val (denormalized for fast org-scoped queries)
    dept_project_id             TEXT NOT NULL,                 -- FK → department.key_val
    official_email              TEXT NOT NULL,

    primary_role_id             TEXT,
    is_active                   SMALLINT DEFAULT 1,
    active_status               SMALLINT DEFAULT 1,

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW(),

    removed_by                  TEXT,
    removed_on                  TIMESTAMPTZ,

    CONSTRAINT fk_dum_org  FOREIGN KEY (org_project_id)  REFERENCES organization (key_val) ON DELETE RESTRICT,
    CONSTRAINT fk_dum_dept FOREIGN KEY (dept_project_id) REFERENCES department   (key_val) ON DELETE RESTRICT
);

COMMENT ON TABLE  dept_user_mapping              IS 'Maps a user to a department with a role. org_project_id is denormalized for fast org-scoped queries.';
COMMENT ON COLUMN dept_user_mapping.active_status IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';
COMMENT ON COLUMN dept_user_mapping.is_active    IS 'Whether this mapping is currently active: 1=active, 0=inactive';

ALTER TABLE dept_user_mapping ADD CONSTRAINT chk_dum_active_status CHECK (active_status IN (1, 9, 5));
ALTER TABLE dept_user_mapping ADD CONSTRAINT chk_dum_is_active     CHECK (is_active IN (0, 1));

CREATE INDEX idx_dum_org_project_id  ON dept_user_mapping (org_project_id);
CREATE INDEX idx_dum_dept_project_id ON dept_user_mapping (dept_project_id);
CREATE INDEX idx_dum_official_email  ON dept_user_mapping (official_email);
CREATE INDEX idx_dum_is_active       ON dept_user_mapping (is_active);
CREATE INDEX idx_dum_active_status   ON dept_user_mapping (active_status);
CREATE INDEX idx_dum_last_modified   ON dept_user_mapping (last_modified_on DESC);
CREATE INDEX idx_dum_org_dept        ON dept_user_mapping (org_project_id, dept_project_id);

-- NOTE: In PostgreSQL production, a partial unique index enforces one active mapping per email per dept:
-- CREATE UNIQUE INDEX uq_dum_active_email_dept ON dept_user_mapping (dept_project_id, official_email) WHERE active_status = 1;
-- In H2 (test), uniqueness is enforced at the application layer.


-- ═══════════════════════════════════════════
-- TABLE: org_user_request
-- ═══════════════════════════════════════════
CREATE TABLE org_user_request (
    -- Identity
    key_val                     TEXT PRIMARY KEY,
    sub_key_type                TEXT,
    key_type                    TEXT,

    -- Status
    active_status               SMALLINT DEFAULT 1,
    request_status              SMALLINT DEFAULT 0,            -- 0=pending, 1=approved, 2=rejected, 3=cancelled

    -- Request info
    official_email              TEXT NOT NULL,
    personal_email              TEXT,
    ref_id                      TEXT,
    version                     INT DEFAULT 1,
    org_web_site                TEXT,

    -- Organization linkage
    org_project_id              TEXT NOT NULL,                 -- FK → organization.key_val

    -- Action audit (who approved/rejected and when)
    actioned_by                 TEXT,                          -- email or key_val of the admin who acted
    actioned_on                 TIMESTAMPTZ,                   -- timestamp of the approval/rejection

    -- Audit
    created_by                  TEXT,
    created_on                  TIMESTAMPTZ DEFAULT NOW(),
    last_modified_by            TEXT,
    last_modified_on            TIMESTAMPTZ DEFAULT NOW(),

    CONSTRAINT fk_our_org       FOREIGN KEY (org_project_id) REFERENCES organization (key_val) ON DELETE RESTRICT
    -- uq_our_email_org removed: replaced by partial unique index below to allow re-requests after rejection/cancellation
);

COMMENT ON TABLE  org_user_request                IS 'Tracks user requests to join an organization. One pending request allowed per email per org at a time.';
COMMENT ON COLUMN org_user_request.active_status  IS 'Object lifecycle: 1=active, 9=archived, 5=deleted';
COMMENT ON COLUMN org_user_request.request_status IS 'Request lifecycle: 0=pending, 1=approved, 2=rejected, 3=cancelled';
COMMENT ON COLUMN org_user_request.official_email IS 'Email of the user requesting to join the org.';
COMMENT ON COLUMN org_user_request.actioned_by    IS 'Email or key_val of the admin who approved or rejected the request.';
COMMENT ON COLUMN org_user_request.actioned_on    IS 'Timestamp when the request was approved or rejected.';

ALTER TABLE org_user_request ADD CONSTRAINT chk_our_active_status  CHECK (active_status IN (1, 9, 5));
ALTER TABLE org_user_request ADD CONSTRAINT chk_our_request_status CHECK (request_status IN (0, 1, 2, 3));

CREATE INDEX idx_our_org_project_id    ON org_user_request (org_project_id);
CREATE INDEX idx_our_official_email    ON org_user_request (official_email);
CREATE INDEX idx_our_request_status    ON org_user_request (request_status);
CREATE INDEX idx_our_active_status     ON org_user_request (active_status);
CREATE INDEX idx_our_last_modified     ON org_user_request (last_modified_on DESC);
CREATE INDEX idx_our_org_req_status    ON org_user_request (org_project_id, request_status);  -- composite: pending requests per org

-- Partial unique index: only one PENDING request per email per org allowed at a time.
-- Rejected/cancelled rows do not block future requests.
CREATE UNIQUE INDEX uq_our_pending_email_org
    ON org_user_request (org_project_id, official_email)
    WHERE request_status = 0;

-- ═══════════════════════════════════════════
-- FULL-TEXT SEARCH — pg_trgm
-- Enables ILIKE partial/fuzzy search on title, name, email fields
-- ═══════════════════════════════════════════
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- organization: search by title
CREATE INDEX idx_org_title_trgm             ON organization USING GIN (title           gin_trgm_ops);

-- department: search by title
CREATE INDEX idx_dept_title_trgm            ON department   USING GIN (title           gin_trgm_ops);

-- users: search by first_name, last_name, emails, and combined full name
CREATE INDEX idx_users_first_name_trgm      ON users            USING GIN (first_name      gin_trgm_ops);
CREATE INDEX idx_users_last_name_trgm       ON users            USING GIN (last_name       gin_trgm_ops);
CREATE INDEX idx_users_official_email_trgm  ON users            USING GIN (official_email  gin_trgm_ops);
CREATE INDEX idx_users_personal_email_trgm  ON users            USING GIN (personal_email  gin_trgm_ops);
CREATE INDEX idx_users_full_name_trgm       ON users            USING GIN ((first_name || ' ' || last_name) gin_trgm_ops);

-- org_user_request: search pending requests by email
CREATE INDEX idx_our_official_email_trgm    ON org_user_request USING GIN (official_email  gin_trgm_ops);
