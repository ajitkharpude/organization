-- Organization Service — logical schema (PostgreSQL; portable DDL, also runs on H2).
--
-- Mirrors the original clouds-orgservice + clouds-user model: each row carries its
-- structured composite-key columns (for filtering/indexing) plus the full document
-- as JSON in `data`. Tenant partitioning is by org-domain string; there are no
-- surrogate FKs. Updates are delete-then-reinsert; deletes are soft (ACTIVE_STATUS=5).
--
-- `data` is TEXT for portability; on PostgreSQL it can be migrated to JSONB if you
-- want in-DB JSON querying (the application treats it as an opaque JSON string).

CREATE TABLE IF NOT EXISTS organization (
    key_val           VARCHAR(512) PRIMARY KEY,
    super_org_domain  VARCHAR(255),
    sub_key_type      VARCHAR(64),
    active_status     VARCHAR(8),
    cml_org_web_site  VARCHAR(255),
    data              TEXT NOT NULL,
    created_on        BIGINT,
    last_modified_on  BIGINT
);
CREATE INDEX IF NOT EXISTS idx_org_lookup
    ON organization (super_org_domain, sub_key_type, active_status, cml_org_web_site);

CREATE TABLE IF NOT EXISTS organization_counter (
    row_key       VARCHAR(512) NOT NULL,
    counter_name  VARCHAR(128) NOT NULL,
    cnt_value     BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (row_key, counter_name)
);

CREATE TABLE IF NOT EXISTS department (
    key_val           VARCHAR(512) PRIMARY KEY,
    cml_org_web_site  VARCHAR(255),
    sub_key_type      VARCHAR(64),
    active_status     VARCHAR(8),
    dept_unique_key   VARCHAR(128),
    data              TEXT NOT NULL,
    created_on        BIGINT,
    last_modified_on  BIGINT
);
CREATE INDEX IF NOT EXISTS idx_dept_lookup
    ON department (cml_org_web_site, sub_key_type, active_status, dept_unique_key);

CREATE TABLE IF NOT EXISTS department_counter (
    row_key       VARCHAR(512) NOT NULL,
    counter_name  VARCHAR(128) NOT NULL,
    cnt_value     BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (row_key, counter_name)
);

CREATE TABLE IF NOT EXISTS app_user (
    key_val            VARCHAR(512) PRIMARY KEY,
    cml_org_web_site   VARCHAR(255),
    role_unique_key    VARCHAR(64),
    cml_is_active      VARCHAR(8),
    cml_official_email VARCHAR(320),
    data               TEXT NOT NULL,
    created_on         BIGINT,
    last_modified_on   BIGINT
);
CREATE INDEX IF NOT EXISTS idx_user_lookup
    ON app_user (cml_org_web_site, role_unique_key, cml_is_active, cml_official_email);

CREATE TABLE IF NOT EXISTS user_orgs (
    row_key            VARCHAR(640) PRIMARY KEY,   -- cml_org_web_site#cml_official_email
    cml_org_web_site   VARCHAR(255),
    super_org_domain   VARCHAR(255),
    cml_official_email VARCHAR(320),
    data               TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_user_orgs_email   ON user_orgs (cml_official_email);
CREATE INDEX IF NOT EXISTS idx_user_orgs_org     ON user_orgs (cml_org_web_site);

CREATE TABLE IF NOT EXISTS org_dept_prp_users (
    row_key            VARCHAR(768) PRIMARY KEY,   -- cml_org_web_site#level_unique_key#cml_official_email
    cml_org_web_site   VARCHAR(255),
    level_unique_key   VARCHAR(128),
    cml_official_email VARCHAR(320),
    role_unique_key    VARCHAR(64),
    cml_version        VARCHAR(32),
    cml_is_active      VARCHAR(8),
    data               TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_odpu_org   ON org_dept_prp_users (cml_org_web_site, level_unique_key);
CREATE INDEX IF NOT EXISTS idx_odpu_email ON org_dept_prp_users (cml_official_email);
