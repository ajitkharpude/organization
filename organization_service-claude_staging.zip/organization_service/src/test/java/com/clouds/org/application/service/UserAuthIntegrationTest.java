package com.clouds.org.application.service;

import com.clouds.org.api.request.LoginRequestDTO;
import com.clouds.org.api.request.RegisterRequestDTO;
import com.clouds.org.api.common.DataArrayRequest;
import com.clouds.org.api.response.UserResponseDTO;
import com.clouds.org.application.port.AuthService;
import com.clouds.org.infrastructure.persistence.repository.UserCredentialRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=PostgreSQL",
    "spring.datasource.driver-class-name=org.h2.Driver",
    "spring.datasource.username=sa",
    "spring.datasource.password=",
    "spring.sql.init.mode=always",
    "spring.sql.init.schema-locations=classpath:schema.sql",
    "spring.flyway.enabled=false",
    "evoke.super-org-id=ORG_1001"
})
class UserAuthIntegrationTest {

    @Autowired
    private AuthService authService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private UserCredentialRepository credentialRepository;

    @BeforeEach
    void setup() {
        // Since we are using H2 and DatabaseSeeder will run, ORG_1001 is already inserted.
        // We can just verify it.
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM organization WHERE key_val='ORG_1001'", Integer.class);
        if (count == null || count == 0) {
            jdbcTemplate.execute("INSERT INTO organization (key_val, active_status, created_by, last_modified_by) VALUES ('ORG_1001', 1, 'sys', 'sys')");
            jdbcTemplate.execute("INSERT INTO wizard (key_val, wizard_type, ref_id, org_project_id, active_status, created_by, last_modified_by) VALUES ('WIZ_USER_1001', 'USER', 'ORG_1001', 'ORG_1001', 1, 'sys', 'sys')");
        }
    }

    @Test
    @Transactional
    void testRegisterAndLogin() {
        // Register User
        RegisterRequestDTO registerRequest = new RegisterRequestDTO();
        registerRequest.setFirstName("web");
        registerRequest.setLastName("three");
        registerRequest.setOrgProjectId("ORG_1001");
        registerRequest.setPersonalEmail("web.three@yopmail.com");
        registerRequest.setPassword("SecretPassword123");
        registerRequest.setOfficialEmail("web.three@cloudsinc.com");
        registerRequest.setDomain("web.three@abc.clouzer.com");
        
        UserResponseDTO registeredUser = authService.register(registerRequest);
        
        assertNotNull(registeredUser);
        assertEquals("web", registeredUser.getFirstName());
        assertNotNull(registeredUser.getKeyVal());
        
        // Login User
        LoginRequestDTO loginRequest = new LoginRequestDTO();
        loginRequest.setOfficialEmail("web.three@cloudsinc.com");
        loginRequest.setPassword("SecretPassword123");
        loginRequest.setOrgProjectId("ORG_1001");
        
        UserResponseDTO loggedInUser = authService.login(loginRequest);
        
        assertNotNull(loggedInUser);
        assertEquals("web.three@cloudsinc.com", loggedInUser.getOfficialEmail());
        
        // Verify user credentials exist in DB
        assertTrue(credentialRepository.findById("web.three@cloudsinc.com").isPresent());
    }
}
