package com.clouds.org.infrastructure.web;

import com.clouds.org.EvokeApplication;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.concurrent.atomic.AtomicReference;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Full end-to-end integration test suite for the Evoke Platform.
 *
 * Covers every HTTP endpoint using MockMvc against an in-memory H2 database.
 * Tests are ordered to reflect the real business flow a QA/BA would walk:
 *
 *   Register → Login → Create Org → Create Dept → Submit Join Request
 *   → Approve → List Mapping → Add to Dept → Update User → Delete
 *
 * Each @Nested class is an independent flow context; shared keys are held
 * in static AtomicReference fields so later tests can reuse created resources.
 */
@SpringBootTest(classes = EvokeApplication.class)
@AutoConfigureMockMvc
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:evoke_it;DB_CLOSE_DELAY=-1;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.sql.init.mode=always",
        "spring.sql.init.platform=",
        "spring.flyway.enabled=false",
        "evoke.super-org-id=ORG_1001",
        "evoke.cache.enabled=false",
        "organization.service.token="
})
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EvokeIntegrationTest {

    @Autowired
    MockMvc mvc;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    JdbcTemplate jdbc;

    // ── Shared state across ordered test methods ──────────────────────────
    static final AtomicReference<String> USER_KEY      = new AtomicReference<>();
    static final AtomicReference<String> USER2_KEY     = new AtomicReference<>();
    static final AtomicReference<String> ORG_KEY       = new AtomicReference<>();
    static final AtomicReference<String> DEPT_KEY      = new AtomicReference<>();
    static final AtomicReference<String> REQUEST_KEY   = new AtomicReference<>();
    static final AtomicReference<String> REQUEST2_KEY  = new AtomicReference<>();
    static final AtomicReference<String> OUM_KEY       = new AtomicReference<>();
    static final AtomicReference<String> DUM_KEY       = new AtomicReference<>();

    // ════════════════════════════════════════════════════════════════════════
    // 1. AUTH — REGISTER
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(10)
    @DisplayName("AUTH-01 | Register: compulsory fields → 201 + user created")
    void register_minimalFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "first_name": "Alice",
                "last_name": "Wonder",
                "org_project_id": "ORG_1001",
                "personal_email": "alice.wonder@gmail.com",
                "official_email": "alice.wonder@company.com",
                "password": "AlicePass@1"
              }]
            }""";

        MvcResult result = mvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Registration successful"))
                .andExpect(jsonPath("$.data.key_val").isNotEmpty())
                .andExpect(jsonPath("$.data.first_name").value("Alice"))
                .andExpect(jsonPath("$.data.last_name").value("Wonder"))
                .andExpect(jsonPath("$.data.official_email").value("alice.wonder@company.com"))
                .andReturn();

        String keyVal = objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText();
        USER_KEY.set(keyVal);
    }

    @Test @Order(11)
    @DisplayName("AUTH-02 | Register: all optional fields → 201 + all fields mapped")
    void register_allOptionalFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "first_name": "Bob",
                "middle_name": "Charles",
                "last_name": "Builder",
                "org_project_id": "ORG_1001",
                "personal_email": "bob.builder@gmail.com",
                "official_email": "bob.builder@company.com",
                "password": "BobPass@2",
                "contact_number": "9123456781",
                "domain": "bob.builder@abc.clouzer.com",
                "dial_code": "+91",
                "city": "Pune",
                "state": "Maharashtra",
                "country": "India",
                "country_code": "IN",
                "continent": "Asia",
                "location": "Pune, MH",
                "latitude": 18.5204,
                "longitude": 73.8567,
                "zipcode": "411001",
                "timezone": "Asia/Kolkata",
                "verificationCode": "VER_99"
              }]
            }""";

        MvcResult result = mvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.first_name").value("Bob"))
                .andExpect(jsonPath("$.data.middle_name").value("Charles"))
                .andReturn();

        USER2_KEY.set(objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText());
    }

    @Test @Order(12)
    @DisplayName("AUTH-03 | Register: duplicate official_email → 409 Conflict")
    void register_duplicateEmail_returns409() throws Exception {
        String body = """
            {
              "dataArray": [{
                "first_name": "Alice",
                "last_name": "Clone",
                "org_project_id": "ORG_1001",
                "personal_email": "alice.clone@gmail.com",
                "official_email": "alice.wonder@company.com",
                "password": "ClonePass@1"
              }]
            }""";

        mvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isConflict());
    }

    @Test @Order(13)
    @DisplayName("AUTH-04 | Register: missing compulsory field → 400 Bad Request")
    void register_missingRequiredField_returns400() throws Exception {
        String body = """
            {
              "dataArray": [{
                "last_name": "NoFirst",
                "org_project_id": "ORG_1001",
                "personal_email": "nofirst@gmail.com",
                "official_email": "nofirst@company.com",
                "password": "Pass@1"
              }]
            }""";

        mvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest());
    }

    @Test @Order(14)
    @DisplayName("AUTH-05 | Register: invalid email format → 400 Bad Request")
    void register_invalidEmail_returns400() throws Exception {
        String body = """
            {
              "dataArray": [{
                "first_name": "Bad",
                "last_name": "Email",
                "org_project_id": "ORG_1001",
                "personal_email": "NOT-AN-EMAIL",
                "official_email": "valid@company.com",
                "password": "Pass@1"
              }]
            }""";

        mvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest());
    }

    // ════════════════════════════════════════════════════════════════════════
    // 2. AUTH — LOGIN
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(20)
    @DisplayName("AUTH-06 | Login: compulsory fields → 200 + user returned")
    void login_success_minimalFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "alice.wonder@company.com",
                "password": "AlicePass@1"
              }]
            }""";

        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Login successful"))
                .andExpect(jsonPath("$.data.official_email").value("alice.wonder@company.com"));
    }

    @Test @Order(21)
    @DisplayName("AUTH-07 | Login: all optional fields → 200")
    void login_success_allOptionalFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "bob.builder@company.com",
                "password": "BobPass@2",
                "org_project_id": "ORG_1001",
                "userDeviceId": "DEVICE-XYZ-001",
                "requestId": "REQ-LOGIN-TEST",
                "userId": "HINT-KEY"
              }]
            }""";

        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.first_name").value("Bob"));
    }

    @Test @Order(22)
    @DisplayName("AUTH-08 | Login: wrong password → 401 Unauthorized")
    void login_wrongPassword_returns401() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "alice.wonder@company.com",
                "password": "WrongPassword!"
              }]
            }""";

        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isUnauthorized());
    }

    @Test @Order(23)
    @DisplayName("AUTH-09 | Login: non-existent email → 404 Not Found")
    void login_unknownEmail_returns404() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "nobody@nowhere.com",
                "password": "Pass@1"
              }]
            }""";

        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isNotFound());
    }

    // ════════════════════════════════════════════════════════════════════════
    // 3. ORGANIZATION — CRUD
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(30)
    @DisplayName("ORG-01 | Create Org: compulsory field only → 201")
    void createOrg_minimal() throws Exception {
        String body = """
            {
              "dataArray": [{ "title": "Test Corp" }]
            }""";

        MvcResult result = mvc.perform(post("/api/orgs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.title").value("Test Corp"))
                .andExpect(jsonPath("$.data.key_val").isNotEmpty())
                .andReturn();

        ORG_KEY.set(objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText());
    }

    @Test @Order(31)
    @DisplayName("ORG-02 | Create Org: all optional fields → 201 + all fields persisted")
    void createOrg_allFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "title": "Full Field Corp",
                "description": "Org with all fields set",
                "org_category": "Technology",
                "org_web_site": "fullfield.clouzerindia.clouzer.com",
                "template_id": "TMPL_001",
                "image_path": "/img/logo.png",
                "city": "Mumbai",
                "state": "Maharashtra",
                "country": "India",
                "country_code": "IN",
                "continent": "Asia",
                "location": "Mumbai, MH",
                "latitude": 19.0760,
                "longitude": 72.8777,
                "zipcode": "400001",
                "timezone": "Asia/Kolkata",
                "project_id": "PROJ_TEST_001",
                "listing_id": "LIST_001",
                "show_compare_graph": 1,
                "property_sync_to_clouzer": true
              }]
            }""";

        mvc.perform(post("/api/orgs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.title").value("Full Field Corp"))
                .andExpect(jsonPath("$.data.city").value("Mumbai"))
                .andExpect(jsonPath("$.data.timezone").value("Asia/Kolkata"));
    }

    @Test @Order(32)
    @DisplayName("ORG-03 | Create Org: missing title → 400")
    void createOrg_missingTitle_returns400() throws Exception {
        String body = """
            {
              "dataArray": [{ "description": "No title here" }]
            }""";

        mvc.perform(post("/api/orgs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest());
    }

    @Test @Order(33)
    @DisplayName("ORG-04 | Get Org by key → 200")
    void getOrg_byKey() throws Exception {
        mvc.perform(get("/api/orgs/{key}", ORG_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.key_val").value(ORG_KEY.get()))
                .andExpect(jsonPath("$.data.title").value("Test Corp"));
    }

    @Test @Order(34)
    @DisplayName("ORG-05 | Get Org: non-existent key → 404")
    void getOrg_notFound_returns404() throws Exception {
        mvc.perform(get("/api/orgs/NON_EXISTENT_ORG"))
                .andExpect(status().isNotFound());
    }

    @Test @Order(35)
    @DisplayName("ORG-06 | List Orgs: no filter → 200 + paginated")
    void listOrgs_noFilter() throws Exception {
        mvc.perform(get("/api/orgs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content").isArray())
                .andExpect(jsonPath("$.data.totalElements").value(greaterThanOrEqualTo(1)));
    }

    @Test @Order(36)
    @DisplayName("ORG-07 | List Orgs: title filter → 200 + filtered result")
    void listOrgs_titleFilter() throws Exception {
        mvc.perform(get("/api/orgs").param("title", "Test Corp"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content[0].title").value("Test Corp"));
    }

    @Test @Order(37)
    @DisplayName("ORG-08 | Update Org: title only → 200")
    void updateOrg_titleOnly() throws Exception {
        String body = """
            {
              "dataArray": [{ "title": "Test Corp Updated" }]
            }""";

        mvc.perform(put("/api/orgs/{key}", ORG_KEY.get())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.title").value("Test Corp Updated"));
    }

    @Test @Order(38)
    @DisplayName("ORG-09 | Update Org: all optional fields → 200")
    void updateOrg_allFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "title": "Test Corp — v2",
                "description": "Updated desc",
                "org_category": "Cloud",
                "org_web_site": "updated.clouzerindia.clouzer.com",
                "city": "Delhi",
                "state": "Delhi",
                "country": "India",
                "country_code": "IN",
                "timezone": "Asia/Kolkata",
                "show_compare_graph": 0,
                "property_sync_to_clouzer": false
              }]
            }""";

        mvc.perform(put("/api/orgs/{key}", ORG_KEY.get())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.city").value("Delhi"));
    }

    // ════════════════════════════════════════════════════════════════════════
    // 4. DEPARTMENT — CRUD
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(40)
    @DisplayName("DEPT-01 | Create Department: compulsory only → 201")
    void createDept_minimal() throws Exception {
        String body = """
            {
              "dataArray": [{ "title": "Engineering" }]
            }""";

        MvcResult result = mvc.perform(post("/api/orgs/{org}/departments", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.title").value("Engineering"))
                .andReturn();

        DEPT_KEY.set(objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText());
    }

    @Test @Order(41)
    @DisplayName("DEPT-02 | Create Department: all optional fields → 201")
    void createDept_allFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "title": "Operations",
                "description": "Handles ops workflows",
                "org_web_site": "ops.engineering.clouzerindia.clouzer.com",
                "image_path": "/img/ops.png",
                "parent_task_id": "TASK_ROOT",
                "default_obj": 0,
                "city": "Pune",
                "state": "Maharashtra",
                "country": "India",
                "country_code": "IN",
                "continent": "Asia",
                "location": "Pune, MH",
                "latitude": 18.5204,
                "longitude": 73.8567,
                "zipcode": "411001",
                "timezone": "Asia/Kolkata",
                "project_id": "PROJ_OPS",
                "listing_id": "LIST_OPS"
              }]
            }""";

        mvc.perform(post("/api/orgs/{org}/departments", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.title").value("Operations"))
                .andExpect(jsonPath("$.data.city").value("Pune"));
    }

    @Test @Order(42)
    @DisplayName("DEPT-03 | Create Department: missing title → 400")
    void createDept_missingTitle_returns400() throws Exception {
        mvc.perform(post("/api/orgs/{org}/departments", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "description": "No title" }] }"""))
                .andExpect(status().isBadRequest());
    }

    @Test @Order(43)
    @DisplayName("DEPT-04 | Create Department: org not found → 404")
    void createDept_orgNotFound_returns404() throws Exception {
        mvc.perform(post("/api/orgs/{org}/departments", "GHOST_ORG")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "title": "Ghost Dept" }] }"""))
                .andExpect(status().isNotFound());
    }

    @Test @Order(44)
    @DisplayName("DEPT-05 | List Departments: no filter → 200 + paginated")
    void listDepts_noFilter() throws Exception {
        mvc.perform(get("/api/orgs/{org}/departments", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content").isArray());
    }

    @Test @Order(45)
    @DisplayName("DEPT-06 | List Departments: title filter → 200")
    void listDepts_titleFilter() throws Exception {
        mvc.perform(get("/api/orgs/{org}/departments", "ORG_1001")
                        .param("title", "Engineering")
                        .param("page", "0")
                        .param("size", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content[0].title").value("Engineering"));
    }

    @Test @Order(46)
    @DisplayName("DEPT-07 | Get Department by key → 200")
    void getDept_byKey() throws Exception {
        mvc.perform(get("/api/orgs/{org}/departments/{dept}", "ORG_1001", DEPT_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.key_val").value(DEPT_KEY.get()));
    }

    @Test @Order(47)
    @DisplayName("DEPT-08 | Get Department: non-existent key → 404")
    void getDept_notFound_returns404() throws Exception {
        mvc.perform(get("/api/orgs/{org}/departments/{dept}", "ORG_1001", "NO_DEPT"))
                .andExpect(status().isNotFound());
    }

    @Test @Order(48)
    @DisplayName("DEPT-09 | Update Department: compulsory only → 200")
    void updateDept_titleOnly() throws Exception {
        mvc.perform(put("/api/orgs/{org}/departments/{dept}", "ORG_1001", DEPT_KEY.get())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "title": "Engineering — Updated" }] }"""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.title").value("Engineering — Updated"));
    }

    @Test @Order(49)
    @DisplayName("DEPT-10 | Update Department: all optional fields → 200")
    void updateDept_allFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "title": "Platform Engineering",
                "description": "Updated desc",
                "default_obj": 1,
                "city": "Bengaluru",
                "state": "Karnataka",
                "timezone": "Asia/Kolkata"
              }]
            }""";

        mvc.perform(put("/api/orgs/{org}/departments/{dept}", "ORG_1001", DEPT_KEY.get())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.city").value("Bengaluru"));
    }

    // ════════════════════════════════════════════════════════════════════════
    // 5. USER — SEARCH + UPDATE + DELETE
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(50)
    @DisplayName("USER-01 | List Users: no filter → 200 + at least 2 users")
    void listUsers_noFilter() throws Exception {
        mvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.totalElements").value(greaterThanOrEqualTo(2)));
    }

    @Test @Order(51)
    @DisplayName("USER-02 | List Users: filter by officialEmail → 200 + 1 result")
    void listUsers_filterByOfficialEmail() throws Exception {
        mvc.perform(get("/api/users")
                        .param("officialEmail", "alice.wonder@company.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content", hasSize(1)))
                .andExpect(jsonPath("$.data.content[0].official_email").value("alice.wonder@company.com"));
    }

    @Test @Order(52)
    @DisplayName("USER-03 | List Users: filter by firstName → 200")
    void listUsers_filterByFirstName() throws Exception {
        mvc.perform(get("/api/users").param("firstName", "Alice"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content[0].first_name").value("Alice"));
    }

    @Test @Order(53)
    @DisplayName("USER-04 | List Users: filter by orgKey → 200 + scoped to org")
    void listUsers_filterByOrgKey() throws Exception {
        mvc.perform(get("/api/users").param("orgKey", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content").isArray());
    }

    @Test @Order(54)
    @DisplayName("USER-05 | List Users: all filters combined → 200")
    void listUsers_allFilters() throws Exception {
        mvc.perform(get("/api/users")
                        .param("firstName", "Alice")
                        .param("lastName", "Wonder")
                        .param("officialEmail", "alice.wonder@company.com")
                        .param("personalEmail", "alice.wonder@gmail.com")
                        .param("orgKey", "ORG_1001")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk());
    }

    @Test @Order(55)
    @DisplayName("USER-06 | Update User: all optional fields → 200 + persisted")
    void updateUser_allFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "first_name": "Alice",
                "middle_name": "B",
                "last_name": "Wonder",
                "contact_number": "9000000001",
                "dial_code": "+91",
                "user_image": "/img/alice.jpg",
                "city": "Pune",
                "state": "Maharashtra",
                "country": "India",
                "country_code": "IN",
                "continent": "Asia",
                "location": "Pune, MH",
                "latitude": 18.5204,
                "longitude": 73.8567,
                "zipcode": "411001",
                "timezone": "Asia/Kolkata"
              }]
            }""";

        mvc.perform(put("/api/users/{key}", USER_KEY.get())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.middle_name").value("B"))
                .andExpect(jsonPath("$.data.city").value("Pune"));
    }

    @Test @Order(56)
    @DisplayName("USER-07 | Update User: partial update (name only) → 200")
    void updateUser_partialUpdate() throws Exception {
        mvc.perform(put("/api/users/{key}", USER_KEY.get())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "first_name": "AliceUpdated" }] }"""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.first_name").value("AliceUpdated"));
    }

    @Test @Order(57)
    @DisplayName("USER-08 | Update User: non-existent key → 404")
    void updateUser_notFound_returns404() throws Exception {
        mvc.perform(put("/api/users/{key}", "GHOST_USER")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "first_name": "Ghost" }] }"""))
                .andExpect(status().isNotFound());
    }

    // ════════════════════════════════════════════════════════════════════════
    // 6. ORG-USER REQUEST — Submit / List / Approve / Reject / Cancel
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(60)
    @DisplayName("REQ-01 | Submit Join Request: compulsory only → 201")
    void submitRequest_minimalFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "alice.wonder@company.com"
              }]
            }""";

        MvcResult result = mvc.perform(post("/api/orgs/{org}/requests", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.official_email").value("alice.wonder@company.com"))
                .andExpect(jsonPath("$.data.request_status").value(0))
                .andReturn();

        REQUEST_KEY.set(objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText());
    }

    @Test @Order(61)
    @DisplayName("REQ-02 | Submit Join Request: all optional fields → 201")
    void submitRequest_allFields() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "bob.builder@company.com",
                "personal_email": "bob.builder@gmail.com",
                "org_web_site": "bob.builder.clouzerindia.clouzer.com"
              }],
              "requestId": "REQ-E2E-001"
            }""";

        MvcResult result = mvc.perform(post("/api/orgs/{org}/requests", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.official_email").value("bob.builder@company.com"))
                .andReturn();

        REQUEST2_KEY.set(objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText());
    }

    @Test @Order(62)
    @DisplayName("REQ-03 | Submit duplicate PENDING request → 409 Conflict")
    void submitRequest_duplicatePending_returns409() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "alice.wonder@company.com"
              }]
            }""";

        mvc.perform(post("/api/orgs/{org}/requests", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isConflict());
    }

    @Test @Order(63)
    @DisplayName("REQ-04 | Submit Request: missing official_email → 400")
    void submitRequest_missingEmail_returns400() throws Exception {
        mvc.perform(post("/api/orgs/{org}/requests", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "personal_email": "only@gmail.com" }] }"""))
                .andExpect(status().isBadRequest());
    }

    @Test @Order(64)
    @DisplayName("REQ-05 | List Requests: no filter → 200 + at least 2 requests")
    void listRequests_noFilter() throws Exception {
        mvc.perform(get("/api/orgs/{org}/requests", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.totalElements").value(greaterThanOrEqualTo(2)));
    }

    @Test @Order(65)
    @DisplayName("REQ-06 | List Requests: status=0 (pending) → 200 + all pending")
    void listRequests_filterByStatus_pending() throws Exception {
        mvc.perform(get("/api/orgs/{org}/requests", "ORG_1001")
                        .param("status", "0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content[*].requestStatus", everyItem(equalTo(0))));
    }

    @Test @Order(66)
    @DisplayName("REQ-07 | List Requests: filter by email → 200")
    void listRequests_filterByEmail() throws Exception {
        mvc.perform(get("/api/orgs/{org}/requests", "ORG_1001")
                        .param("email", "alice.wonder@company.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content[0].official_email").value("alice.wonder@company.com"));
    }

    @Test @Order(67)
    @DisplayName("REQ-08 | List Requests: all filters + pagination → 200")
    void listRequests_allFilters() throws Exception {
        mvc.perform(get("/api/orgs/{org}/requests", "ORG_1001")
                        .param("status", "0")
                        .param("email", "alice.wonder@company.com")
                        .param("page", "0")
                        .param("size", "10")
                        .param("sort", "createdOn,desc"))
                .andExpect(status().isOk());
    }

    @Test @Order(68)
    @DisplayName("REQ-09 | Cancel Request → 200 + status=3")
    void cancelRequest() throws Exception {
        // Cancel Bob's request (REQUEST2_KEY) so we can test re-request later
        mvc.perform(patch("/api/orgs/{org}/requests/{req}/cancel", "ORG_1001", REQUEST2_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.request_status").value(3));
    }

    @Test @Order(69)
    @DisplayName("REQ-10 | Approve Request: no body → 200 + status=1")
    void approveRequest_noBody() throws Exception {
        mvc.perform(patch("/api/orgs/{org}/requests/{req}/approve", "ORG_1001", REQUEST_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.request_status").value(1));
    }

    @Test @Order(70)
    @DisplayName("REQ-11 | Re-submit request after cancel → 201 (partial unique allows it)")
    void resubmitRequestAfterCancel() throws Exception {
        String body = """
            {
              "dataArray": [{
                "official_email": "bob.builder@company.com"
              }]
            }""";

        MvcResult result = mvc.perform(post("/api/orgs/{org}/requests", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andReturn();

        // Reject this one to test the reject flow
        String newReqKey = objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText();

        mvc.perform(patch("/api/orgs/{org}/requests/{req}/reject", "ORG_1001", newReqKey))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.request_status").value(2));
    }

    @Test @Order(71)
    @DisplayName("REQ-12 | Approve Request: with primary_role_id and actioned_by → 200")
    void approveRequest_withOptionalBody() throws Exception {
        // Submit a new request for bob first (previous rejected)
        String submitBody = """
            {
              "dataArray": [{ "official_email": "bob.builder@company.com" }]
            }""";

        MvcResult submitResult = mvc.perform(post("/api/orgs/{org}/requests", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(submitBody))
                .andExpect(status().isCreated())
                .andReturn();

        String bobReqKey = objectMapper.readTree(submitResult.getResponse().getContentAsString())
                .path("data").path("key_val").asText();

        String approveBody = """
            {
              "dataArray": [{
                "actioned_by": "admin@company.com"
              }]
            }""";

        mvc.perform(patch("/api/orgs/{org}/requests/{req}/approve", "ORG_1001", bobReqKey)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(approveBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.request_status").value(1));
    }

    @Test @Order(72)
    @DisplayName("REQ-13 | Approve already-approved request → 4xx error")
    void approveAlreadyApprovedRequest_returnsError() throws Exception {
        mvc.perform(patch("/api/orgs/{org}/requests/{req}/approve", "ORG_1001", REQUEST_KEY.get()))
                .andExpect(status().is4xxClientError());
    }

    // ════════════════════════════════════════════════════════════════════════
    // 7. ORG-USER MAPPING — List / Get / Delete
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(80)
    @DisplayName("OUM-01 | List Mappings: required org_key → 200 + at least 1 mapping")
    void listOrgUserMappings() throws Exception {
        MvcResult result = mvc.perform(get("/api/org-users")
                        .param("org_key", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content").isArray())
                .andExpect(jsonPath("$.data.totalElements").value(greaterThanOrEqualTo(1)))
                .andReturn();

        OUM_KEY.set(objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("content").get(0).path("key_val").asText());
    }

    @Test @Order(81)
    @DisplayName("OUM-02 | List Mappings: filter by email → 200")
    void listOrgUserMappings_filterByEmail() throws Exception {
        mvc.perform(get("/api/org-users")
                        .param("org_key", "ORG_1001")
                        .param("email", "alice.wonder@company.com"))
                .andExpect(status().isOk());
    }

    @Test @Order(82)
    @DisplayName("OUM-03 | List Mappings: pagination params → 200")
    void listOrgUserMappings_withPagination() throws Exception {
        mvc.perform(get("/api/org-users")
                        .param("org_key", "ORG_1001")
                        .param("page", "0")
                        .param("size", "5")
                        .param("sort", "createdOn,desc"))
                .andExpect(status().isOk());
    }

    @Test @Order(83)
    @DisplayName("OUM-04 | Get single Mapping by key → 200")
    void getOrgUserMapping_byKey() throws Exception {
        mvc.perform(get("/api/org-users/{key}", OUM_KEY.get())
                        .param("org_key", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.key_val").value(OUM_KEY.get()));
    }

    @Test @Order(84)
    @DisplayName("OUM-05 | Get Mapping: non-existent key → 404")
    void getOrgUserMapping_notFound() throws Exception {
        mvc.perform(get("/api/org-users/{key}", "GHOST_OUM")
                        .param("org_key", "ORG_1001"))
                .andExpect(status().isNotFound());
    }

    // ════════════════════════════════════════════════════════════════════════
    // 8. DEPT-USER MAPPING — CRUD
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(90)
    @DisplayName("DUM-01 | Add User to Dept: compulsory fields only → 201")
    void addUserToDept_minimal() throws Exception {
        String body = String.format("""
            {
              "dataArray": [{
                "dept_project_id": "%s",
                "official_email": "alice.wonder@company.com"
              }]
            }""", DEPT_KEY.get());

        MvcResult result = mvc.perform(post("/api/dept-users")
                        .param("org_key", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.official_email").value("alice.wonder@company.com"))
                .andReturn();

        DUM_KEY.set(objectMapper.readTree(result.getResponse().getContentAsString())
                .path("data").path("key_val").asText());
    }

    @Test @Order(91)
    @DisplayName("DUM-02 | Add User to Dept: with role_type=4 (Manager) → 201")
    void addUserToDept_withRoleType() throws Exception {
        String body = String.format("""
            {
              "dataArray": [{
                "dept_project_id": "%s",
                "official_email": "bob.builder@company.com",
                "role_type": 4
              }]
            }""", DEPT_KEY.get());

        mvc.perform(post("/api/dept-users")
                        .param("org_key", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.role_type").value(4));
    }

    @Test @Order(92)
    @DisplayName("DUM-03 | Add User to Dept: duplicate active mapping → 409")
    void addUserToDept_duplicate_returns409() throws Exception {
        String body = String.format("""
            {
              "dataArray": [{
                "dept_project_id": "%s",
                "official_email": "alice.wonder@company.com"
              }]
            }""", DEPT_KEY.get());

        mvc.perform(post("/api/dept-users")
                        .param("org_key", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isConflict());
    }

    @Test @Order(93)
    @DisplayName("DUM-04 | Add User to Dept: missing dept_project_id → 400")
    void addUserToDept_missingDeptId_returns400() throws Exception {
        mvc.perform(post("/api/dept-users")
                        .param("org_key", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "official_email": "alice.wonder@company.com" }] }"""))
                .andExpect(status().isBadRequest());
    }

    @Test @Order(94)
    @DisplayName("DUM-05 | List Dept Mappings: org_key only → 200 + all dept members")
    void listDeptMappings_orgKeyOnly() throws Exception {
        mvc.perform(get("/api/dept-users").param("org_key", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content").isArray());
    }

    @Test @Order(95)
    @DisplayName("DUM-06 | List Dept Mappings: filter by dept_key → 200")
    void listDeptMappings_filterByDeptKey() throws Exception {
        mvc.perform(get("/api/dept-users")
                        .param("org_key", "ORG_1001")
                        .param("dept_key", DEPT_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content").isArray());
    }

    @Test @Order(96)
    @DisplayName("DUM-07 | List Dept Mappings: all filters + pagination → 200")
    void listDeptMappings_allFilters() throws Exception {
        mvc.perform(get("/api/dept-users")
                        .param("org_key", "ORG_1001")
                        .param("dept_key", DEPT_KEY.get())
                        .param("email", "alice.wonder@company.com")
                        .param("page", "0")
                        .param("size", "10")
                        .param("sort", "createdOn,desc"))
                .andExpect(status().isOk());
    }

    @Test @Order(97)
    @DisplayName("DUM-08 | Get single Dept Mapping → 200")
    void getDeptMapping_byKey() throws Exception {
        mvc.perform(get("/api/dept-users/{key}", DUM_KEY.get())
                        .param("org_key", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.key_val").value(DUM_KEY.get()));
    }

    @Test @Order(98)
    @DisplayName("DUM-09 | Get Dept Mapping: non-existent key → 404")
    void getDeptMapping_notFound() throws Exception {
        mvc.perform(get("/api/dept-users/{key}", "GHOST_DUM")
                        .param("org_key", "ORG_1001"))
                .andExpect(status().isNotFound());
    }

    @Test @Order(99)
    @DisplayName("DUM-10 | Remove User from Dept → 200")
    void removeUserFromDept() throws Exception {
        mvc.perform(delete("/api/dept-users/{key}", DUM_KEY.get())
                        .param("org_key", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("User removed from department successfully"));
    }

    @Test @Order(100)
    @DisplayName("DUM-11 | Re-add user to dept after removal → 201 (partial unique allows it)")
    void reAddUserToDeptAfterRemoval() throws Exception {
        String body = String.format("""
            {
              "dataArray": [{
                "dept_project_id": "%s",
                "official_email": "alice.wonder@company.com",
                "role_type": 1
              }]
            }""", DEPT_KEY.get());

        mvc.perform(post("/api/dept-users")
                        .param("org_key", "ORG_1001")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated());
    }

    // ════════════════════════════════════════════════════════════════════════
    // 9. TEAR-DOWN — Remove Org Mapping (also verifies cascade dept cleanup)
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(110)
    @DisplayName("OUM-06 | Remove User from Org → 200 + cascades dept mapping removal")
    void removeUserFromOrg() throws Exception {
        mvc.perform(delete("/api/org-users/{key}", OUM_KEY.get())
                        .param("org_key", "ORG_1001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message",
                        containsString("User removed from organization successfully")));
    }

    @Test @Order(111)
    @DisplayName("DEPT-11 | Soft-Delete Department → 200")
    void softDeleteDept() throws Exception {
        mvc.perform(delete("/api/orgs/{org}/departments/{dept}", "ORG_1001", DEPT_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Department deleted successfully"));
    }

    @Test @Order(112)
    @DisplayName("USER-09 | Soft-Delete User → 200")
    void softDeleteUser() throws Exception {
        mvc.perform(delete("/api/users/{key}", USER2_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("User deleted successfully"));
    }

    @Test @Order(113)
    @DisplayName("USER-10 | Soft-Delete User: non-existent key → 404")
    void softDeleteUser_notFound() throws Exception {
        mvc.perform(delete("/api/users/{key}", "GHOST_USER"))
                .andExpect(status().isNotFound());
    }

    @Test @Order(114)
    @DisplayName("ORG-10 | Soft-Delete Org → 200")
    void softDeleteOrg() throws Exception {
        mvc.perform(delete("/api/orgs/{key}", ORG_KEY.get()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Organization deleted successfully"));
    }

    // ════════════════════════════════════════════════════════════════════════
    // 10. VALIDATION EDGE CASES
    // ════════════════════════════════════════════════════════════════════════

    @Test @Order(120)
    @DisplayName("VAL-01 | Empty dataArray → 4xx error")
    void emptyDataArray_returnsError() throws Exception {
        mvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [] }"""))
                .andExpect(status().is4xxClientError());
    }

    @Test @Order(121)
    @DisplayName("VAL-02 | Missing dataArray key → 4xx error")
    void missingDataArrayKey_returnsError() throws Exception {
        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "official_email": "alice@co.com", "password": "x" }"""))
                .andExpect(status().is4xxClientError());
    }

    @Test @Order(122)
    @DisplayName("VAL-03 | Request to org-user endpoint without org_key param → 4xx")
    void listOrgUsers_missingOrgKey_returnsError() throws Exception {
        mvc.perform(get("/api/org-users"))
                .andExpect(status().is4xxClientError());
    }

    @Test @Order(123)
    @DisplayName("VAL-04 | Add to dept without org_key query param → 4xx")
    void addToDept_missingOrgKey_returnsError() throws Exception {
        mvc.perform(post("/api/dept-users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            { "dataArray": [{ "dept_project_id": "D1", "official_email": "x@y.com" }] }"""))
                .andExpect(status().is4xxClientError());
    }
}
